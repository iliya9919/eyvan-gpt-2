#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
File Handler for Telegram Real Estate Bot
Handles file uploads and processing
"""

import json
import csv
import os
import logging
import tempfile
from typing import Dict, List, Any, Optional
from telegram import Update, Document
from telegram.ext import ContextTypes
from io import StringIO

from config import Config
from property_manager import PropertyManager
from utils.validators import PropertyValidator

class FileHandler:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.property_manager = PropertyManager()
        
    async def handle_file_upload(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> Dict:
        """Handle file upload from Telegram"""
        try:
            document = update.message.document
            
            # Validate file
            validation_result = self._validate_file(document)
            if not validation_result['valid']:
                return {
                    'success': False,
                    'error': validation_result['error'],
                    'added': 0,
                    'skipped': 0
                }
            
            # Download file
            file_path = await self._download_file(document, context)
            
            # Process file based on type
            if document.file_name.lower().endswith('.json'):
                result = await self._process_json_file(file_path)
            elif document.file_name.lower().endswith('.csv'):
                result = await self._process_csv_file(file_path)
            else:
                result = {
                    'success': False,
                    'error': 'فرمت فایل پشتیبانی نمی‌شود',
                    'added': 0,
                    'skipped': 0
                }
            
            # Clean up temporary file
            try:
                os.remove(file_path)
            except:
                pass
                
            return result
            
        except Exception as e:
            self.logger.error(f"Error handling file upload: {e}")
            return {
                'success': False,
                'error': f'خطا در پردازش فایل: {str(e)}',
                'added': 0,
                'skipped': 0
            }
            
    def _validate_file(self, document: Document) -> Dict:
        """Validate uploaded file"""
        # Check file size
        if document.file_size > Config.MAX_FILE_SIZE:
            return {
                'valid': False,
                'error': f'حجم فایل بیش از {Config.MAX_FILE_SIZE / (1024 * 1024)} مگابایت است'
            }
        
        # Check file extension
        if not document.file_name:
            return {
                'valid': False,
                'error': 'نام فایل نامعتبر است'
            }
            
        file_ext = os.path.splitext(document.file_name.lower())[1]
        if file_ext not in Config.ALLOWED_FILE_TYPES:
            return {
                'valid': False,
                'error': f'فرمت فایل پشتیبانی نمی‌شود. فرمت‌های مجاز: {", ".join(Config.ALLOWED_FILE_TYPES)}'
            }
            
        return {'valid': True}
        
    async def _download_file(self, document: Document, context: ContextTypes.DEFAULT_TYPE) -> str:
        """Download file to temporary location"""
        file = await context.bot.get_file(document.file_id)
        
        # Create temporary file
        temp_dir = tempfile.gettempdir()
        temp_file = os.path.join(temp_dir, f"upload_{document.file_unique_id}_{document.file_name}")
        
        # Download file
        await file.download_to_drive(temp_file)
        
        return temp_file
        
    async def _process_json_file(self, file_path: str) -> Dict:
        """Process JSON file containing properties"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Ensure data is a list
            if isinstance(data, dict):
                data = [data]
            elif not isinstance(data, list):
                return {
                    'success': False,
                    'error': 'فرمت JSON نامعتبر است. باید آرایه از املاک باشد.',
                    'added': 0,
                    'skipped': 0
                }
            
            # Process properties
            return await self._process_properties_data(data)
            
        except json.JSONDecodeError as e:
            return {
                'success': False,
                'error': f'خطا در پردازش JSON: {str(e)}',
                'added': 0,
                'skipped': 0
            }
        except Exception as e:
            return {
                'success': False,
                'error': f'خطا در پردازش فایل: {str(e)}',
                'added': 0,
                'skipped': 0
            }
            
    async def _process_csv_file(self, file_path: str) -> Dict:
        """Process CSV file containing properties"""
        try:
            properties = []
            
            with open(file_path, 'r', encoding='utf-8') as f:
                csv_reader = csv.DictReader(f)
                
                # Required CSV columns
                required_columns = ['code', 'type', 'address', 'price', 'area', 'bedrooms']
                
                # Check if required columns exist
                if not all(col in csv_reader.fieldnames for col in required_columns):
                    return {
                        'success': False,
                        'error': f'ستون‌های مورد نیاز یافت نشد: {", ".join(required_columns)}',
                        'added': 0,
                        'skipped': 0
                    }
                
                # Process each row
                for row_num, row in enumerate(csv_reader, 1):
                    try:
                        # Convert and validate data
                        property_data = {
                            'code': row['code'].strip(),
                            'type': row['type'].strip(),
                            'address': row['address'].strip(),
                            'price': int(row['price']),
                            'area': int(row['area']),
                            'bedrooms': int(row['bedrooms']),
                            'description': row.get('description', '').strip(),
                            'year_built': int(row.get('year_built', 0)) if row.get('year_built') else None,
                            'floor': int(row.get('floor', 0)) if row.get('floor') else None
                        }
                        
                        # Remove None values
                        property_data = {k: v for k, v in property_data.items() if v is not None}
                        
                        properties.append(property_data)
                        
                    except (ValueError, TypeError) as e:
                        self.logger.warning(f"Error processing row {row_num}: {e}")
                        continue
                        
            if not properties:
                return {
                    'success': False,
                    'error': 'هیچ ملک معتبری در فایل یافت نشد',
                    'added': 0,
                    'skipped': 0
                }
                
            # Process properties
            return await self._process_properties_data(properties)
            
        except Exception as e:
            return {
                'success': False,
                'error': f'خطا در پردازش CSV: {str(e)}',
                'added': 0,
                'skipped': 0
            }
            
    async def _process_properties_data(self, properties: List[Dict]) -> Dict:
        """Process properties data and add to database"""
        result = {
            'success': True,
            'added': 0,
            'skipped': 0,
            'errors': []
        }
        
        for prop in properties:
            try:
                # Validate property data
                validation_errors = PropertyValidator.validate_property_data(prop)
                if validation_errors:
                    result['skipped'] += 1
                    result['errors'].append(f"ملک {prop.get('code', 'نامشخص')}: {', '.join(validation_errors.values())}")
                    continue
                
                # Check if property already exists
                if self.property_manager.get_property_by_code(prop['code']):
                    result['skipped'] += 1
                    result['errors'].append(f"ملک {prop['code']} قبلاً وجود دارد")
                    continue
                
                # Add property
                if self.property_manager.add_property(prop):
                    result['added'] += 1
                else:
                    result['skipped'] += 1
                    result['errors'].append(f"خطا در افزودن ملک {prop['code']}")
                    
            except Exception as e:
                result['skipped'] += 1
                result['errors'].append(f"خطا در پردازش ملک {prop.get('code', 'نامشخص')}: {str(e)}")
                
        # Update success status
        result['success'] = result['added'] > 0
        
        return result
        
    def export_properties_to_csv(self) -> str:
        """Export properties to CSV format"""
        try:
            properties = self.property_manager.get_all_properties()
            
            if not properties:
                return ""
                
            # Create CSV content
            output = StringIO()
            fieldnames = ['code', 'type', 'address', 'price', 'area', 'bedrooms', 'year_built', 'floor', 'description', 'created_at']
            
            writer = csv.DictWriter(output, fieldnames=fieldnames)
            writer.writeheader()
            
            for prop in properties:
                # Ensure all fields exist
                row = {field: prop.get(field, '') for field in fieldnames}
                writer.writerow(row)
                
            return output.getvalue()
            
        except Exception as e:
            self.logger.error(f"Error exporting properties to CSV: {e}")
            return ""
            
    def export_customers_to_csv(self) -> str:
        """Export customers to CSV format"""
        try:
            from customer_manager import CustomerManager
            customer_manager = CustomerManager()
            customers = customer_manager.get_all_customers()
            
            if not customers:
                return ""
                
            # Create CSV content
            output = StringIO()
            fieldnames = ['user_id', 'first_name', 'last_name', 'username', 'phone_number', 'registration_date', 'status']
            
            writer = csv.DictWriter(output, fieldnames=fieldnames)
            writer.writeheader()
            
            for customer in customers:
                # Ensure all fields exist
                row = {field: customer.get(field, '') for field in fieldnames}
                writer.writerow(row)
                
            return output.getvalue()
            
        except Exception as e:
            self.logger.error(f"Error exporting customers to CSV: {e}")
            return ""
            
    def validate_json_structure(self, data: Any) -> Dict:
        """Validate JSON structure for properties"""
        if not isinstance(data, list):
            return {
                'valid': False,
                'error': 'JSON باید آرایه از املاک باشد'
            }
            
        if not data:
            return {
                'valid': False,
                'error': 'فایل JSON خالی است'
            }
            
        # Check first item structure
        first_item = data[0]
        if not isinstance(first_item, dict):
            return {
                'valid': False,
                'error': 'ساختار JSON نامعتبر است'
            }
            
        required_fields = ['code', 'type', 'address', 'price', 'area', 'bedrooms']
        missing_fields = [field for field in required_fields if field not in first_item]
        
        if missing_fields:
            return {
                'valid': False,
                'error': f'فیلدهای مورد نیاز یافت نشد: {", ".join(missing_fields)}'
            }
            
        return {'valid': True}
        
    def get_sample_json(self) -> str:
        """Get sample JSON structure for properties"""
        sample = [
            {
                "code": "EV001",
                "type": "آپارتمان",
                "address": "تهران، خیابان ولیعصر، پلاک 123",
                "price": 800000000,
                "area": 85,
                "bedrooms": 2,
                "year_built": 1398,
                "floor": 3,
                "description": "آپارتمان دو خواب با نور عالی"
            },
            {
                "code": "EV002",
                "type": "ویلا",
                "address": "کرج، شهرک غرب، بلوار آزادی",
                "price": 2500000000,
                "area": 200,
                "bedrooms": 4,
                "year_built": 1399,
                "floor": 2,
                "description": "ویلا دوبلکس با حیاط"
            }
        ]
        
        return json.dumps(sample, ensure_ascii=False, indent=2)
        
    def get_sample_csv(self) -> str:
        """Get sample CSV structure for properties"""
        return """code,type,address,price,area,bedrooms,year_built,floor,description
EV001,آپارتمان,تهران، خیابان ولیعصر، پلاک 123,800000000,85,2,1398,3,آپارتمان دو خواب با نور عالی
EV002,ویلا,کرج، شهرک غرب، بلوار آزادی,2500000000,200,4,1399,2,ویلا دوبلکس با حیاط"""
