# Telegram Real Estate Bot (Eivan Properties)

## Overview

This is a Telegram bot built for a real estate company (Eivan Properties) that helps customers search for properties, register as customers, and interact with AI-powered property assistance. The bot is designed to handle Persian language interactions and provides both customer-facing features and admin management capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Framework**: Python-based Telegram bot using `python-telegram-bot` library
- **Language**: Python 3 with UTF-8 encoding for Persian language support
- **Architecture Pattern**: Modular design with separate managers for different functionalities
- **Entry Point**: `main.py` serves as the application entry point with polling-based updates
- **AI Integration**: OpenAI GPT-4o for intelligent message processing and property recommendations

### Data Storage
- **Database**: JSON-based file storage system (no traditional database)
- **Files**: Separate JSON files for properties, customers, requests, admins, and customizable texts
- **Location**: All data stored in `/data` directory
- **Backup**: Manual export capabilities to CSV format

## Key Components

### Bot Handlers (`bot_handlers.py`)
- Handles all Telegram commands (`/start`, `/help`, `/search`, `/register`, `/report`)
- Processes text messages and contact sharing
- Manages user interactions with reply keyboards
- Supports Persian language interface
- Integrates with GPT for intelligent responses

### Property Management (`property_manager.py`)
- JSON-based property storage with fields: code, type, address, price, area, bedrooms, year_built, floor, description
- Property search functionality by code (format: EV + numbers)
- CRUD operations for property management
- Property validation and data integrity

### Customer Management (`customer_manager.py`)
- Customer registration with Telegram user data
- Request tracking for all customer interactions
- JSON-based storage for customer profiles and requests
- Export capabilities for customer data

### GPT Integration (`gpt_integration.py`)
- Uses OpenAI GPT-4o model for AI-powered responses
- Processes natural language queries about properties
- Contextual understanding of Persian real estate terminology
- Customizable system prompts for different scenarios

### Admin Management (`admin_manager.py`)
- Admin authentication system
- Role-based permissions
- Admin user management
- Default admin configuration from environment variables

### Text Management (`text_manager.py`)
- Centralized text storage for customizable bot messages
- Persian language support
- Admin-editable welcome messages and prompts
- Default text fallbacks

### File Processing (`file_handler.py`)
- Handles JSON and CSV file uploads through Telegram
- Batch property import capabilities
- File validation and error handling
- Support for property data bulk operations

## Data Flow

1. **User Interaction**: Users interact with bot through Telegram interface
2. **Command Processing**: Bot handlers parse commands and route to appropriate managers
3. **Data Operations**: Managers perform CRUD operations on JSON files
4. **AI Processing**: GPT integration processes natural language queries
5. **Response Generation**: Responses are formatted and sent back to users
6. **Logging**: All interactions are logged for monitoring and debugging

## External Dependencies

### Core Libraries
- `python-telegram-bot`: Telegram Bot API wrapper
- `openai`: OpenAI GPT API integration
- `json`: Data serialization
- `logging`: Application logging
- `datetime`: Timestamp management

### Environment Variables
- `TELEGRAM_BOT_TOKEN`: Bot authentication token
- `OPENAI_API_KEY`: OpenAI API access key
- `ADMIN_USER_IDS`: Comma-separated list of admin user IDs
- `WEBHOOK_URL`: Optional webhook URL for deployment
- `LOG_LEVEL`: Logging verbosity level

## Deployment Strategy

### Local Development
- Uses polling method for receiving updates
- JSON files stored locally in `/data` directory
- Logs stored in `/logs` directory
- Configuration through environment variables

### Production Considerations
- Supports webhook mode for better performance
- Environment variable configuration
- File-based logging system
- No database dependencies (purely file-based)

### Scalability Limitations
- JSON file storage limits concurrent access
- No distributed deployment support
- Single-instance architecture
- Manual data backup and restore

### Security Features
- Admin authentication through user ID verification
- Input validation for all user inputs
- Secure API key management through environment variables
- Rate limiting through Telegram's built-in mechanisms

## Configuration Management

The system uses a centralized configuration class (`Config`) that:
- Loads settings from environment variables
- Provides default values for all configurations
- Manages file paths and directory structure
- Handles company information and bot settings
- Configures GPT model parameters and API settings

## Error Handling

- Comprehensive exception handling in all managers
- Fallback mechanisms for missing data files
- Graceful degradation when external services are unavailable
- Detailed error logging for debugging purposes
- User-friendly error messages in Persian language