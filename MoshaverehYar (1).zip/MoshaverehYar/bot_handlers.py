#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bot Handlers for Telegram Real Estate Bot
Handles all user interactions and bot commands
"""

import logging
import json
import os
from typing import Dict, List, Optional
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from telegram.ext import ContextTypes
from datetime import datetime

from config import Config
from property_manager import PropertyManager
from customer_manager import CustomerManager
from gpt_integration import GPTIntegration
from text_manager import TextManager
from json_to_text import JsonToText
from file_handler import FileHandler
from admin_manager import AdminManager
from utils.logger import BotLogger
from utils.validators import PropertyValidator, CustomerValidator, MessageValidator

class BotHandlers:
    def __init__(self):
        self.logger = BotLogger(__name__)
        self.property_manager = PropertyManager()
        self.customer_manager = CustomerManager()
        self.gpt = GPTIntegration()
        self.text_manager = TextManager()
        self.json_to_text = JsonToText()
        self.file_handler = FileHandler()
        self.admin_manager = AdminManager()
        
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command"""
        user_id = update.effective_user.id
        self.logger.log_user_interaction(user_id, "start")
        
        # Create keyboard
        keyboard = [
            [KeyboardButton("🏠 جستجوی املاک"), KeyboardButton("📋 ثبت نام")],
            [KeyboardButton("📞 تماس با مشاور"), KeyboardButton("❓ راهنما")]
        ]
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
        
        welcome_message = self.text_manager.get_text("welcome_message")
        
        await update.message.reply_text(
            welcome_message,
            reply_markup=reply_markup,
            parse_mode='HTML'
        )
        
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command"""
        user_id = update.effective_user.id
        self.logger.log_user_interaction(user_id, "help")
        
        if self.admin_manager.is_admin(user_id):
            help_text = self.text_manager.get_text("admin_help")
        else:
            help_text = self.text_manager.get_text("user_help")
            
        await update.message.reply_text(help_text, parse_mode='HTML')
        
    async def search_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /search command"""
        user_id = update.effective_user.id
        
        # Check if there's a search query
        query = ' '.join(context.args) if context.args else ''
        
        if not query:
            await update.message.reply_text(
                self.text_manager.get_text("search_help"),
                parse_mode='HTML'
            )
            return
            
        # Search properties
        results = self.property_manager.search_properties(query)
        
        if not results:
            await update.message.reply_text(
                self.text_manager.get_text("no_results_found")
            )
            return
            
        # Convert results to beautiful text
        formatted_results = await self.json_to_text.properties_to_text(results)
        
        self.logger.log_property_search(user_id, query, len(results))
        
        await update.message.reply_text(
            formatted_results,
            parse_mode='HTML'
        )
        
    async def register_customer(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /register command"""
        user_id = update.effective_user.id
        
        # Check if already registered
        if self.customer_manager.is_registered(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("already_registered")
            )
            return
            
        # Request contact sharing
        keyboard = [[KeyboardButton("📱 اشتراک شماره تلفن", request_contact=True)]]
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)
        
        await update.message.reply_text(
            self.text_manager.get_text("request_contact"),
            reply_markup=reply_markup
        )
        
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle text messages"""
        user_id = update.effective_user.id
        message_text = update.message.text
        
        # Log user request
        self.customer_manager.log_user_request(
            user_id, 
            update.effective_user.first_name or "Unknown",
            message_text
        )
        
        # Validate message
        validation_errors = MessageValidator.validate_message(message_text)
        if validation_errors:
            await update.message.reply_text(
                self.text_manager.get_text("invalid_message")
            )
            return
            
        # Sanitize message
        clean_message = MessageValidator.sanitize_message(message_text)
        
        # Handle button clicks
        if clean_message in ["🏠 جستجوی املاک", "📋 ثبت نام", "📞 تماس با مشاور", "❓ راهنما"]:
            await self._handle_button_click(update, context, clean_message)
            return
            
        # Check if it's a property code
        if PropertyValidator.validate_property_code(clean_message):
            await self._handle_property_code(update, context, clean_message)
            return
            
        # Process with GPT
        try:
            response = await self.gpt.process_message(clean_message, user_id)
            await update.message.reply_text(response, parse_mode='HTML')
        except Exception as e:
            self.logger.log_error(e, "GPT processing")
            await update.message.reply_text(
                self.text_manager.get_text("error_processing_message")
            )
            
    async def _handle_button_click(self, update: Update, context: ContextTypes.DEFAULT_TYPE, button_text: str):
        """Handle button clicks"""
        if button_text == "🏠 جستجوی املاک":
            await update.message.reply_text(
                self.text_manager.get_text("search_help"),
                parse_mode='HTML'
            )
        elif button_text == "📋 ثبت نام":
            await self.register_customer(update, context)
        elif button_text == "📞 تماس با مشاور":
            await update.message.reply_text(
                self.text_manager.get_text("contact_info"),
                parse_mode='HTML'
            )
        elif button_text == "❓ راهنما":
            await self.help_command(update, context)
            
    async def _handle_property_code(self, update: Update, context: ContextTypes.DEFAULT_TYPE, code: str):
        """Handle property code requests"""
        property_data = self.property_manager.get_property_by_code(code)
        
        if not property_data:
            await update.message.reply_text(
                self.text_manager.get_text("property_not_found")
            )
            return
            
        # Convert property to beautiful text
        formatted_property = await self.json_to_text.property_to_text(property_data)
        
        await update.message.reply_text(
            formatted_property,
            parse_mode='HTML'
        )
        
    async def handle_contact(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle contact sharing"""
        user_id = update.effective_user.id
        contact = update.message.contact
        
        if contact.user_id != user_id:
            await update.message.reply_text(
                self.text_manager.get_text("invalid_contact")
            )
            return
            
        # Register customer
        success = self.customer_manager.register_customer(
            user_id,
            update.effective_user.first_name,
            update.effective_user.last_name,
            update.effective_user.username,
            contact.phone_number
        )
        
        if success:
            self.logger.log_customer_registration(user_id, contact.phone_number)
            
            # Create main keyboard
            keyboard = [
                [KeyboardButton("🏠 جستجوی املاک"), KeyboardButton("📋 ثبت نام")],
                [KeyboardButton("📞 تماس با مشاور"), KeyboardButton("❓ راهنما")]
            ]
            reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
            
            await update.message.reply_text(
                self.text_manager.get_text("registration_success"),
                reply_markup=reply_markup
            )
        else:
            await update.message.reply_text(
                self.text_manager.get_text("registration_failed")
            )
            
    async def handle_document(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle document uploads"""
        user_id = update.effective_user.id
        
        # Check if user is admin
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        # Process file upload
        try:
            result = await self.file_handler.handle_file_upload(update, context)
            
            # Convert result to beautiful text
            formatted_result = await self.json_to_text.upload_result_to_text(result)
            
            await update.message.reply_text(
                formatted_result,
                parse_mode='HTML'
            )
        except Exception as e:
            self.logger.log_error(e, "File upload")
            await update.message.reply_text(
                self.text_manager.get_text("file_upload_error")
            )
            
    # Admin Commands
    async def admin_customers(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """List all customers (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        customers = self.customer_manager.get_all_customers()
        
        if not customers:
            await update.message.reply_text(
                self.text_manager.get_text("no_customers")
            )
            return
            
        # Convert to beautiful text
        formatted_customers = await self.json_to_text.customers_to_text(customers)
        
        await update.message.reply_text(
            formatted_customers,
            parse_mode='HTML'
        )
        
    async def admin_stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show statistics (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        stats = {
            'properties': self.property_manager.get_property_stats(),
            'customers': self.customer_manager.get_customer_stats(),
            'requests': self.customer_manager.get_request_stats()
        }
        
        # Convert to beautiful text
        formatted_stats = await self.json_to_text.stats_to_text(stats)
        
        await update.message.reply_text(
            formatted_stats,
            parse_mode='HTML'
        )
        
    async def admin_list_properties(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """List all properties (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        properties = self.property_manager.get_all_properties()
        
        if not properties:
            await update.message.reply_text(
                self.text_manager.get_text("no_properties")
            )
            return
            
        # Convert to beautiful text
        formatted_properties = await self.json_to_text.properties_to_text(properties)
        
        await update.message.reply_text(
            formatted_properties,
            parse_mode='HTML'
        )
        
    async def admin_add_admin(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Add new admin (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        if not context.args:
            await update.message.reply_text(
                self.text_manager.get_text("add_admin_help")
            )
            return
            
        try:
            new_admin_id = int(context.args[0])
            name = ' '.join(context.args[1:]) if len(context.args) > 1 else "Unknown"
            
            success = self.admin_manager.add_admin(new_admin_id, name, user_id)
            
            if success:
                await update.message.reply_text(
                    self.text_manager.get_text("admin_added_success").format(
                        admin_id=new_admin_id, name=name
                    )
                )
            else:
                await update.message.reply_text(
                    self.text_manager.get_text("admin_already_exists")
                )
        except ValueError:
            await update.message.reply_text(
                self.text_manager.get_text("invalid_user_id")
            )
            
    async def admin_remove_admin(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Remove admin (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        if not context.args:
            await update.message.reply_text(
                self.text_manager.get_text("remove_admin_help")
            )
            return
            
        try:
            admin_id_to_remove = int(context.args[0])
            success = self.admin_manager.remove_admin(admin_id_to_remove, user_id)
            
            if success:
                await update.message.reply_text(
                    self.text_manager.get_text("admin_removed_success").format(
                        admin_id=admin_id_to_remove
                    )
                )
            else:
                await update.message.reply_text(
                    self.text_manager.get_text("admin_remove_failed")
                )
        except ValueError:
            await update.message.reply_text(
                self.text_manager.get_text("invalid_user_id")
            )
            
    async def admin_list_admins(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """List all admins (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        admins = self.admin_manager.get_all_admins()
        
        # Convert to beautiful text
        formatted_admins = await self.json_to_text.admins_to_text(admins)
        
        await update.message.reply_text(
            formatted_admins,
            parse_mode='HTML'
        )
        
    async def admin_edit_texts(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Edit bot texts (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        if len(context.args) < 2:
            await update.message.reply_text(
                self.text_manager.get_text("edit_texts_help")
            )
            return
            
        key = context.args[0]
        new_text = ' '.join(context.args[1:])
        
        success = self.text_manager.update_text(key, new_text)
        
        if success:
            await update.message.reply_text(
                self.text_manager.get_text("text_updated_success").format(key=key)
            )
        else:
            await update.message.reply_text(
                self.text_manager.get_text("text_update_failed")
            )
            
    async def admin_reset_text(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Reset text to default (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        if not context.args:
            await update.message.reply_text(
                self.text_manager.get_text("reset_text_help")
            )
            return
            
        key = context.args[0]
        success = self.text_manager.reset_text(key)
        
        if success:
            await update.message.reply_text(
                self.text_manager.get_text("text_reset_success").format(key=key)
            )
        else:
            await update.message.reply_text(
                self.text_manager.get_text("text_reset_failed")
            )
            
    async def admin_upload_properties(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Upload properties help (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        await update.message.reply_text(
            self.text_manager.get_text("upload_properties_help"),
            parse_mode='HTML'
        )
        
    # Other admin commands with similar structure...
    async def admin_add_property(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Add new property (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        await update.message.reply_text(
            self.text_manager.get_text("add_property_help"),
            parse_mode='HTML'
        )
        
    async def admin_edit_property(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Edit property (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        await update.message.reply_text(
            self.text_manager.get_text("edit_property_help"),
            parse_mode='HTML'
        )
        
    async def admin_delete_property(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Delete property (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        await update.message.reply_text(
            self.text_manager.get_text("delete_property_help"),
            parse_mode='HTML'
        )
        
    async def admin_edit_welcome(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Edit welcome message (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        await update.message.reply_text(
            self.text_manager.get_text("edit_welcome_help"),
            parse_mode='HTML'
        )
        
    async def admin_edit_company(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Edit company info (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        await update.message.reply_text(
            self.text_manager.get_text("edit_company_help"),
            parse_mode='HTML'
        )
        
    async def admin_edit_prompts(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Edit GPT prompts (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        await update.message.reply_text(
            self.text_manager.get_text("edit_prompts_help"),
            parse_mode='HTML'
        )
        
    async def admin_export_data(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Export data (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        await update.message.reply_text(
            self.text_manager.get_text("export_data_help"),
            parse_mode='HTML'
        )
        
    async def admin_backup(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Backup data (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        await update.message.reply_text(
            self.text_manager.get_text("backup_help"),
            parse_mode='HTML'
        )
        
    async def admin_settings(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Show settings (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        await update.message.reply_text(
            self.text_manager.get_text("settings_help"),
            parse_mode='HTML'
        )
        
    async def admin_report(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Generate report (admin only)"""
        user_id = update.effective_user.id
        
        if not self.admin_manager.is_admin(user_id):
            await update.message.reply_text(
                self.text_manager.get_text("access_denied")
            )
            return
            
        # Generate comprehensive report
        report_data = {
            'timestamp': datetime.now().isoformat(),
            'properties': self.property_manager.get_property_stats(),
            'customers': self.customer_manager.get_customer_stats(),
            'requests': self.customer_manager.get_request_stats(),
            'recent_activity': self.customer_manager.get_recent_requests(10)
        }
        
        # Convert to beautiful text
        formatted_report = await self.json_to_text.report_to_text(report_data)
        
        await update.message.reply_text(
            formatted_report,
            parse_mode='HTML'
        )
