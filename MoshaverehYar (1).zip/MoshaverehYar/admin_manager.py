#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Admin Manager for Telegram Real Estate Bot
Handles admin authentication and management
"""

import json
import os
import logging
from typing import List, Dict, Optional
from datetime import datetime
from config import Config

class AdminManager:
    def __init__(self, admins_file: str = None):
        self.admins_file = admins_file or Config.ADMINS_FILE
        self.logger = logging.getLogger(__name__)
        self.admins = self.load_admins()
        
    def load_admins(self) -> List[Dict]:
        """Load admins from JSON file"""
        try:
            if os.path.exists(self.admins_file):
                with open(self.admins_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                # Create directory if it doesn't exist
                os.makedirs(os.path.dirname(self.admins_file), exist_ok=True)
                # Initialize with default admin from config
                return self.get_default_admins()
        except Exception as e:
            self.logger.error(f"Error loading admins: {e}")
            return self.get_default_admins()
            
    def get_default_admins(self) -> List[Dict]:
        """Get default admins from config"""
        default_admins = []
        
        for admin_id in Config.ADMIN_USER_IDS:
            default_admins.append({
                'user_id': admin_id,
                'name': 'مدیر اصلی',
                'added_by': 'system',
                'added_at': datetime.now().isoformat(),
                'status': 'active',
                'permissions': ['all']
            })
            
        return default_admins
        
    def save_admins(self) -> bool:
        """Save admins to JSON file"""
        try:
            with open(self.admins_file, 'w', encoding='utf-8') as f:
                json.dump(self.admins, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            self.logger.error(f"Error saving admins: {e}")
            return False
            
    def is_admin(self, user_id: int) -> bool:
        """Check if user is admin"""
        # Check config first (for backward compatibility)
        if user_id in Config.ADMIN_USER_IDS:
            return True
            
        # Check admin database
        for admin in self.admins:
            if admin['user_id'] == user_id and admin.get('status') == 'active':
                return True
                
        return False
        
    def add_admin(self, user_id: int, name: str, added_by: int) -> bool:
        """Add new admin"""
        try:
            # Check if user is already admin
            if self.is_admin(user_id):
                return False
                
            # Check if the person adding is admin
            if not self.is_admin(added_by):
                return False
                
            admin = {
                'user_id': user_id,
                'name': name,
                'added_by': added_by,
                'added_at': datetime.now().isoformat(),
                'status': 'active',
                'permissions': ['all']
            }
            
            self.admins.append(admin)
            return self.save_admins()
            
        except Exception as e:
            self.logger.error(f"Error adding admin: {e}")
            return False
            
    def remove_admin(self, user_id: int, removed_by: int) -> bool:
        """Remove admin"""
        try:
            # Check if the person removing is admin
            if not self.is_admin(removed_by):
                return False
                
            # Don't allow removing config admins
            if user_id in Config.ADMIN_USER_IDS:
                return False
                
            # Remove from admins list
            original_count = len(self.admins)
            self.admins = [admin for admin in self.admins if admin['user_id'] != user_id]
            
            if len(self.admins) < original_count:
                return self.save_admins()
                
            return False
            
        except Exception as e:
            self.logger.error(f"Error removing admin: {e}")
            return False
            
    def get_admin_by_id(self, user_id: int) -> Optional[Dict]:
        """Get admin by user ID"""
        for admin in self.admins:
            if admin['user_id'] == user_id:
                return admin
        return None
        
    def get_all_admins(self) -> List[Dict]:
        """Get all admins"""
        return self.admins
        
    def update_admin_status(self, user_id: int, status: str) -> bool:
        """Update admin status"""
        try:
            for admin in self.admins:
                if admin['user_id'] == user_id:
                    admin['status'] = status
                    admin['updated_at'] = datetime.now().isoformat()
                    return self.save_admins()
            return False
        except Exception as e:
            self.logger.error(f"Error updating admin status: {e}")
            return False
            
    def get_admin_permissions(self, user_id: int) -> List[str]:
        """Get admin permissions"""
        # Config admins have all permissions
        if user_id in Config.ADMIN_USER_IDS:
            return ['all']
            
        admin = self.get_admin_by_id(user_id)
        if admin:
            return admin.get('permissions', [])
            
        return []
        
    def has_permission(self, user_id: int, permission: str) -> bool:
        """Check if admin has specific permission"""
        if not self.is_admin(user_id):
            return False
            
        permissions = self.get_admin_permissions(user_id)
        return 'all' in permissions or permission in permissions
        
    def get_admin_stats(self) -> Dict:
        """Get admin statistics"""
        active_admins = sum(1 for admin in self.admins if admin.get('status') == 'active')
        
        return {
            'total_admins': len(self.admins),
            'active_admins': active_admins,
            'config_admins': len(Config.ADMIN_USER_IDS)
        }
        
    def log_admin_action(self, user_id: int, action: str, details: str = "") -> bool:
        """Log admin action"""
        try:
            admin = self.get_admin_by_id(user_id)
            if not admin:
                return False
                
            if 'actions' not in admin:
                admin['actions'] = []
                
            admin['actions'].append({
                'action': action,
                'details': details,
                'timestamp': datetime.now().isoformat()
            })
            
            # Keep only last 100 actions
            admin['actions'] = admin['actions'][-100:]
            
            return self.save_admins()
            
        except Exception as e:
            self.logger.error(f"Error logging admin action: {e}")
            return False
            
    def get_admin_actions(self, user_id: int, limit: int = 20) -> List[Dict]:
        """Get admin actions"""
        admin = self.get_admin_by_id(user_id)
        if not admin or 'actions' not in admin:
            return []
            
        actions = admin['actions']
        actions.sort(key=lambda x: x['timestamp'], reverse=True)
        return actions[:limit]
        
    def cleanup_inactive_admins(self, days: int = 90) -> int:
        """Remove inactive admins"""
        try:
            from datetime import datetime, timedelta
            
            cutoff_date = datetime.now() - timedelta(days=days)
            original_count = len(self.admins)
            
            # Keep config admins and recently active admins
            active_admins = []
            for admin in self.admins:
                # Always keep config admins
                if admin['user_id'] in Config.ADMIN_USER_IDS:
                    active_admins.append(admin)
                    continue
                    
                # Check last activity
                last_activity = admin.get('updated_at', admin.get('added_at'))
                if last_activity:
                    try:
                        last_activity_date = datetime.fromisoformat(last_activity)
                        if last_activity_date > cutoff_date:
                            active_admins.append(admin)
                    except:
                        # If we can't parse the date, keep the admin
                        active_admins.append(admin)
                else:
                    # If no activity date, keep the admin
                    active_admins.append(admin)
                    
            self.admins = active_admins
            removed_count = original_count - len(self.admins)
            
            if removed_count > 0:
                self.save_admins()
                
            return removed_count
            
        except Exception as e:
            self.logger.error(f"Error cleaning up inactive admins: {e}")
            return 0
