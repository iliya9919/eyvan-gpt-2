#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Validation utilities for Telegram Real Estate Bot
"""

import re
from typing import Optional, Dict, Any, List
from config import Config

class PropertyValidator:
    """Validator for property data"""
    
    @staticmethod
    def validate_property_code(code: str) -> bool:
        """Validate property code format"""
        if not code:
            return False
        # Property codes should be in format: EV + numbers
        pattern = r'^EV\d+$'
        return bool(re.match(pattern, code.upper()))
    
    @staticmethod
    def validate_price(price: Any) -> bool:
        """Validate price value"""
        try:
            price_val = int(price)
            return price_val > 0
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def validate_area(area: Any) -> bool:
        """Validate area value"""
        try:
            area_val = int(area)
            return area_val > 0
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def validate_bedrooms(bedrooms: Any) -> bool:
        """Validate bedrooms count"""
        try:
            bedrooms_val = int(bedrooms)
            return 0 <= bedrooms_val <= 10
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def validate_property_type(prop_type: str) -> bool:
        """Validate property type"""
        return prop_type in Config.PROPERTY_TYPES
    
    @staticmethod
    def validate_year_built(year: Any) -> bool:
        """Validate year built"""
        try:
            year_val = int(year)
            return 1300 <= year_val <= 1450  # Persian calendar years
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def validate_floor(floor: Any) -> bool:
        """Validate floor number"""
        try:
            floor_val = int(floor)
            return -5 <= floor_val <= 50  # Reasonable range
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def validate_property_data(data: Dict) -> Dict[str, str]:
        """Validate complete property data"""
        errors = {}
        
        # Required fields
        required_fields = ['code', 'type', 'address', 'price', 'area', 'bedrooms']
        for field in required_fields:
            if field not in data or not str(data[field]).strip():
                errors[field] = f"فیلد {field} الزامی است"
        
        # Validate specific fields
        if 'code' in data and data['code'] and not PropertyValidator.validate_property_code(data['code']):
            errors['code'] = "کد ملک باید در فرمت EV + اعداد باشد (مثال: EV001)"
        
        if 'price' in data and data['price'] and not PropertyValidator.validate_price(data['price']):
            errors['price'] = "قیمت باید عدد مثبت باشد"
        
        if 'area' in data and data['area'] and not PropertyValidator.validate_area(data['area']):
            errors['area'] = "متراژ باید عدد مثبت باشد"
        
        if 'bedrooms' in data and data['bedrooms'] is not None and not PropertyValidator.validate_bedrooms(data['bedrooms']):
            errors['bedrooms'] = "تعداد اتاق خواب باید بین 0 تا 10 باشد"
        
        if 'type' in data and data['type'] and not PropertyValidator.validate_property_type(data['type']):
            errors['type'] = f"نوع ملک باید یکی از موارد زیر باشد: {', '.join(Config.PROPERTY_TYPES)}"
        
        if 'year_built' in data and data['year_built'] and not PropertyValidator.validate_year_built(data['year_built']):
            errors['year_built'] = "سال ساخت نامعتبر است"
        
        if 'floor' in data and data['floor'] is not None and not PropertyValidator.validate_floor(data['floor']):
            errors['floor'] = "شماره طبقه نامعتبر است"
        
        # Validate address length
        if 'address' in data and data['address'] and len(data['address']) < 10:
            errors['address'] = "آدرس باید حداقل 10 کاراکتر باشد"
        
        # Validate description length
        if 'description' in data and data['description'] and len(data['description']) > 1000:
            errors['description'] = "توضیحات نباید بیش از 1000 کاراکتر باشد"
        
        return errors

class CustomerValidator:
    """Validator for customer data"""
    
    @staticmethod
    def validate_phone_number(phone: str) -> bool:
        """Validate Iranian phone number"""
        if not phone:
            return False
        
        # Remove spaces and dashes
        phone = phone.replace(' ', '').replace('-', '').replace('(', '').replace(')', '')
        
        # Check Iranian mobile number patterns
        patterns = [
            r'^09\d{9}$',           # 09xxxxxxxxx
            r'^\+989\d{9}$',        # +989xxxxxxxxx
            r'^00989\d{9}$',        # 00989xxxxxxxxx
            r'^989\d{9}$',          # 989xxxxxxxxx
            r'^9\d{9}$'             # 9xxxxxxxxx
        ]
        
        return any(re.match(pattern, phone) for pattern in patterns)
    
    @staticmethod
    def validate_name(name: str) -> bool:
        """Validate name (Persian/English letters only)"""
        if not name or len(name.strip()) < 2:
            return False
        
        # Allow Persian and English letters, spaces
        pattern = r'^[\u0600-\u06FFa-zA-Z\s]+$'
        return bool(re.match(pattern, name.strip()))
    
    @staticmethod
    def validate_username(username: str) -> bool:
        """Validate Telegram username"""
        if not username:
            return True  # Username is optional
        
        # Remove @ if present
        if username.startswith('@'):
            username = username[1:]
        
        # Telegram username pattern
        pattern = r'^[a-zA-Z0-9_]{5,32}$'
        return bool(re.match(pattern, username))
    
    @staticmethod
    def validate_user_id(user_id: Any) -> bool:
        """Validate Telegram user ID"""
        try:
            user_id_val = int(user_id)
            return user_id_val > 0
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def validate_customer_data(data: Dict) -> Dict[str, str]:
        """Validate complete customer data"""
        errors = {}
        
        # Validate user ID
        if 'user_id' in data and not CustomerValidator.validate_user_id(data['user_id']):
            errors['user_id'] = "شناسه کاربر نامعتبر است"
        
        # Validate first name
        if 'first_name' in data and not CustomerValidator.validate_name(data['first_name']):
            errors['first_name'] = "نام نامعتبر است (حداقل 2 کاراکتر، فقط حروف)"
        
        # Validate last name
        if 'last_name' in data and data['last_name'] and not CustomerValidator.validate_name(data['last_name']):
            errors['last_name'] = "نام خانوادگی نامعتبر است (فقط حروف)"
        
        # Validate username
        if 'username' in data and not CustomerValidator.validate_username(data['username']):
            errors['username'] = "نام کاربری نامعتبر است"
        
        # Validate phone number
        if 'phone_number' in data and not CustomerValidator.validate_phone_number(data['phone_number']):
            errors['phone_number'] = "شماره تلفن نامعتبر است (فرمت: 09xxxxxxxxx)"
        
        return errors

class SearchValidator:
    """Validator for search queries"""
    
    @staticmethod
    def validate_price_range(min_price: Any, max_price: Any) -> bool:
        """Validate price range"""
        try:
            min_val = int(min_price) if min_price else 0
            max_val = int(max_price) if max_price else float('inf')
            return min_val >= 0 and max_val >= min_val
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def validate_area_range(min_area: Any, max_area: Any) -> bool:
        """Validate area range"""
        try:
            min_val = int(min_area) if min_area else 0
            max_val = int(max_area) if max_area else float('inf')
            return min_val >= 0 and max_val >= min_val
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def sanitize_search_query(query: str) -> str:
        """Sanitize search query"""
        if not query:
            return ""
        
        # Remove extra spaces
        query = ' '.join(query.split())
        
        # Remove potentially harmful characters
        query = re.sub(r'[<>"\']', '', query)
        
        # Limit length
        if len(query) > 200:
            query = query[:200]
        
        return query.strip()
    
    @staticmethod
    def validate_search_params(params: Dict) -> Dict[str, str]:
        """Validate search parameters"""
        errors = {}
        
        # Validate price range
        if 'min_price' in params or 'max_price' in params:
            if not SearchValidator.validate_price_range(
                params.get('min_price'), 
                params.get('max_price')
            ):
                errors['price'] = "محدوده قیمت نامعتبر است"
        
        # Validate area range
        if 'min_area' in params or 'max_area' in params:
            if not SearchValidator.validate_area_range(
                params.get('min_area'), 
                params.get('max_area')
            ):
                errors['area'] = "محدوده متراژ نامعتبر است"
        
        # Validate property type
        if 'type' in params and params['type']:
            if not PropertyValidator.validate_property_type(params['type']):
                errors['type'] = "نوع ملک نامعتبر است"
        
        # Validate bedrooms
        if 'bedrooms' in params and params['bedrooms'] is not None:
            if not PropertyValidator.validate_bedrooms(params['bedrooms']):
                errors['bedrooms'] = "تعداد اتاق خواب نامعتبر است"
        
        return errors

class MessageValidator:
    """Validator for messages and user input"""
    
    @staticmethod
    def is_spam(message: str) -> bool:
        """Check if message is spam"""
        if not message:
            return False
        
        # Check for excessive repetition
        words = message.split()
        if len(words) > 5 and len(set(words)) < len(words) * 0.3:
            return True
        
        # Check for excessive length
        if len(message) > Config.MAX_MESSAGE_LENGTH:
            return True
        
        # Check for spam patterns
        spam_patterns = [
            r'(.)\1{10,}',          # Repeated characters
            r'\b(http|www|\.com|\.ir)\b',  # URLs
            r'\b\d{10,}\b',         # Long numbers
            r'[!@#$%^&*]{5,}',      # Special characters spam
        ]
        
        for pattern in spam_patterns:
            if re.search(pattern, message, re.IGNORECASE):
                return True
        
        return False
    
    @staticmethod
    def contains_profanity(message: str) -> bool:
        """Check if message contains profanity"""
        # Persian profanity words (basic list)
        profanity_words = [
            'کیر', 'کون', 'جنده', 'فاحشه', 'لعنتی', 'عوضی'
        ]
        
        message_lower = message.lower()
        return any(word in message_lower for word in profanity_words)
    
    @staticmethod
    def sanitize_message(message: str) -> str:
        """Sanitize user message"""
        if not message:
            return ""
        
        # Remove excessive whitespace
        message = ' '.join(message.split())
        
        # Remove potentially harmful characters
        message = re.sub(r'[<>"\']', '', message)
        
        # Remove zero-width characters
        message = re.sub(r'[\u200b-\u200f\u2060-\u206f]', '', message)
        
        # Limit length
        if len(message) > Config.MAX_MESSAGE_LENGTH:
            message = message[:Config.MAX_MESSAGE_LENGTH] + "..."
        
        return message.strip()
    
    @staticmethod
    def validate_message(message: str) -> Dict[str, str]:
        """Validate message"""
        errors = {}
        
        if not message or not message.strip():
            errors['message'] = "پیام خالی است"
        elif MessageValidator.is_spam(message):
            errors['message'] = "پیام اسپم تشخیص داده شد"
        elif MessageValidator.contains_profanity(message):
            errors['message'] = "پیام شامل کلمات نامناسب است"
        elif len(message.strip()) < 2:
            errors['message'] = "پیام خیلی کوتاه است"
        
        return errors

class FileValidator:
    """Validator for file uploads"""
    
    @staticmethod
    def validate_file_size(size: int) -> bool:
        """Validate file size"""
        return 0 < size <= Config.MAX_FILE_SIZE
    
    @staticmethod
    def validate_file_extension(filename: str) -> bool:
        """Validate file extension"""
        if not filename:
            return False
        
        file_ext = os.path.splitext(filename.lower())[1]
        return file_ext in Config.ALLOWED_FILE_TYPES
    
    @staticmethod
    def validate_file_name(filename: str) -> bool:
        """Validate file name"""
        if not filename:
            return False
        
        # Check for dangerous characters
        dangerous_chars = ['<', '>', ':', '"', '|', '?', '*', '\\', '/']
        return not any(char in filename for char in dangerous_chars)
    
    @staticmethod
    def is_safe_file_content(content: str) -> bool:
        """Check if file content is safe"""
        # Check for potential script injection
        dangerous_patterns = [
            r'<script',
            r'javascript:',
            r'vbscript:',
            r'onload=',
            r'onerror=',
            r'eval\(',
            r'exec\(',
        ]
        
        content_lower = content.lower()
        return not any(re.search(pattern, content_lower) for pattern in dangerous_patterns)

class AdminValidator:
    """Validator for admin operations"""
    
    @staticmethod
    def validate_admin_user_id(user_id: Any) -> bool:
        """Validate admin user ID"""
        try:
            user_id_val = int(user_id)
            return user_id_val > 0
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def validate_admin_name(name: str) -> bool:
        """Validate admin name"""
        if not name or len(name.strip()) < 2:
            return False
        
        # Allow Persian and English letters, spaces
        pattern = r'^[\u0600-\u06FFa-zA-Z\s]+$'
        return bool(re.match(pattern, name.strip()))
    
    @staticmethod
    def validate_permission(permission: str) -> bool:
        """Validate admin permission"""
        valid_permissions = [
            'all', 'properties', 'customers', 'stats', 'export',
            'texts', 'admins', 'backup', 'settings'
        ]
        return permission in valid_permissions
    
    @staticmethod
    def validate_admin_data(data: Dict) -> Dict[str, str]:
        """Validate admin data"""
        errors = {}
        
        # Validate user ID
        if 'user_id' in data and not AdminValidator.validate_admin_user_id(data['user_id']):
            errors['user_id'] = "شناسه کاربر نامعتبر است"
        
        # Validate name
        if 'name' in data and not AdminValidator.validate_admin_name(data['name']):
            errors['name'] = "نام ادمین نامعتبر است"
        
        # Validate permissions
        if 'permissions' in data and isinstance(data['permissions'], list):
            for perm in data['permissions']:
                if not AdminValidator.validate_permission(perm):
                    errors['permissions'] = f"دسترسی '{perm}' نامعتبر است"
                    break
        
        return errors
