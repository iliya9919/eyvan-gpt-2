#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Logging utilities for Telegram Real Estate Bot
"""

import logging
import os
from datetime import datetime
from config import Config

def setup_logging():
    """Setup logging configuration"""
    
    # Create logs directory if it doesn't exist
    log_dir = Config.LOGS_DIR
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # Configure logging
    log_level = getattr(logging, Config.LOG_LEVEL.upper(), logging.INFO)
    
    # Create formatters
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    console_formatter = logging.Formatter(
        '%(levelname)s - %(name)s - %(message)s'
    )
    
    # Create handlers
    file_handler = logging.FileHandler(
        os.path.join(log_dir, Config.LOG_FILE), 
        encoding='utf-8'
    )
    file_handler.setLevel(log_level)
    file_handler.setFormatter(file_formatter)
    
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    console_handler.setFormatter(console_formatter)
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)
    
    # Reduce noise from external libraries
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("openai").setLevel(logging.WARNING)
    
    return root_logger

def get_logger(name: str) -> logging.Logger:
    """Get logger instance"""
    return logging.getLogger(name)

class BotLogger:
    """Bot-specific logger with additional functionality"""
    
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
        
    def log_user_interaction(self, user_id: int, action: str, message: str = ""):
        """Log user interaction"""
        self.logger.info(f"User {user_id} - {action}: {message}")
        
    def log_property_search(self, user_id: int, query: str, results_count: int):
        """Log property search"""
        self.logger.info(f"Property search - User {user_id} - Query: {query} - Results: {results_count}")
        
    def log_customer_registration(self, user_id: int, phone: str):
        """Log customer registration"""
        self.logger.info(f"Customer registered - User {user_id} - Phone: {phone}")
        
    def log_error(self, error: Exception, context: str = ""):
        """Log error with context"""
        self.logger.error(f"Error in {context}: {str(error)}", exc_info=True)
        
    def log_admin_action(self, user_id: int, action: str, details: str = ""):
        """Log admin action"""
        self.logger.info(f"Admin action - User {user_id} - Action: {action} - Details: {details}")
        
    def log_system_event(self, event: str, details: str = ""):
        """Log system event"""
        self.logger.info(f"System event - {event}: {details}")
        
    def log_file_upload(self, user_id: int, filename: str, size: int, result: str):
        """Log file upload"""
        self.logger.info(f"File upload - User {user_id} - File: {filename} - Size: {size} - Result: {result}")
        
    def log_gpt_request(self, user_id: int, prompt_type: str, success: bool):
        """Log GPT request"""
        status = "success" if success else "failed"
        self.logger.info(f"GPT request - User {user_id} - Type: {prompt_type} - Status: {status}")
        
    def log_database_operation(self, operation: str, table: str, success: bool, details: str = ""):
        """Log database operation"""
        status = "success" if success else "failed"
        self.logger.info(f"Database operation - {operation} - Table: {table} - Status: {status} - Details: {details}")
        
    def log_security_event(self, user_id: int, event: str, details: str = ""):
        """Log security event"""
        self.logger.warning(f"Security event - User {user_id} - Event: {event} - Details: {details}")
        
    def log_performance_metric(self, metric: str, value: float, unit: str = ""):
        """Log performance metric"""
        self.logger.info(f"Performance metric - {metric}: {value} {unit}")
