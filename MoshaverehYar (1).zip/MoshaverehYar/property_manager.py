#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Property Manager for Telegram Real Estate Bot
Handles property data management and search functionality
"""

import json
import os
import logging
from typing import List, Dict, Optional
from datetime import datetime

class PropertyManager:
    def __init__(self, data_file: str = "data/properties.json"):
        self.data_file = data_file
        self.logger = logging.getLogger(__name__)
        self.properties = self.load_properties()
        
    def load_properties(self) -> List[Dict]:
        """Load properties from JSON file"""
        try:
            if os.path.exists(self.data_file):
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                # Create directory if it doesn't exist
                os.makedirs(os.path.dirname(self.data_file), exist_ok=True)
                # Return empty list if file doesn't exist
                return []
        except Exception as e:
            self.logger.error(f"Error loading properties: {e}")
            return []
            
    def save_properties(self) -> bool:
        """Save properties to JSON file"""
        try:
            with open(self.data_file, 'w', encoding='utf-8') as f:
                json.dump(self.properties, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            self.logger.error(f"Error saving properties: {e}")
            return False
            
    def get_property_by_code(self, code: str) -> Optional[Dict]:
        """Get property by code"""
        for prop in self.properties:
            if prop.get('code', '').upper() == code.upper():
                return prop
        return None
        
    def search_properties(self, query: str) -> List[Dict]:
        """Search properties based on query"""
        if not query.strip():
            return []
            
        query = query.lower()
        results = []
        
        for prop in self.properties:
            # Search in all text fields
            searchable_text = f"{prop.get('type', '')} {prop.get('address', '')} {prop.get('description', '')}".lower()
            
            # Check if query matches any field
            if (query in searchable_text or 
                self.matches_price_range(prop.get('price', 0), query) or
                self.matches_area_range(prop.get('area', 0), query) or
                str(prop.get('bedrooms', 0)) in query):
                results.append(prop)
                
        return results
        
    def matches_price_range(self, price: int, query: str) -> bool:
        """Check if price matches query range"""
        try:
            # Extract numbers from query
            import re
            numbers = re.findall(r'\d+', query)
            
            if not numbers:
                return False
                
            # Convert to appropriate unit (millions)
            query_price = int(numbers[0])
            
            # Check for price range keywords
            if 'زیر' in query or 'کمتر' in query or 'تا' in query:
                return price <= query_price * 1000000
            elif 'بالای' in query or 'بیشتر' in query or 'از' in query:
                return price >= query_price * 1000000
            else:
                # Approximate match (within 20% range)
                return abs(price - query_price * 1000000) <= (query_price * 1000000 * 0.2)
                
        except:
            return False
            
    def matches_area_range(self, area: int, query: str) -> bool:
        """Check if area matches query range"""
        try:
            import re
            numbers = re.findall(r'\d+', query)
            
            if not numbers:
                return False
                
            query_area = int(numbers[0])
            
            # Check for area range keywords
            if 'متر' in query:
                return abs(area - query_area) <= 20  # Within 20 sqm
                
            return False
        except:
            return False
            
    def add_property(self, property_data: Dict) -> bool:
        """Add new property"""
        try:
            # Validate required fields
            required_fields = ['code', 'type', 'address', 'price', 'area', 'bedrooms']
            for field in required_fields:
                if field not in property_data:
                    raise ValueError(f"Missing required field: {field}")
                    
            # Check if code already exists
            if self.get_property_by_code(property_data['code']):
                raise ValueError(f"Property code {property_data['code']} already exists")
                
            # Add timestamp
            property_data['created_at'] = datetime.now().isoformat()
            
            self.properties.append(property_data)
            return self.save_properties()
            
        except Exception as e:
            self.logger.error(f"Error adding property: {e}")
            return False
            
    def update_property(self, code: str, updates: Dict) -> bool:
        """Update existing property"""
        try:
            for i, prop in enumerate(self.properties):
                if prop.get('code', '').upper() == code.upper():
                    self.properties[i].update(updates)
                    self.properties[i]['updated_at'] = datetime.now().isoformat()
                    return self.save_properties()
            return False
        except Exception as e:
            self.logger.error(f"Error updating property: {e}")
            return False
            
    def delete_property(self, code: str) -> bool:
        """Delete property by code"""
        try:
            original_count = len(self.properties)
            self.properties = [prop for prop in self.properties if prop.get('code', '').upper() != code.upper()]
            if len(self.properties) < original_count:
                return self.save_properties()
            return False
        except Exception as e:
            self.logger.error(f"Error deleting property: {e}")
            return False
            
    def get_all_properties(self) -> List[Dict]:
        """Get all properties"""
        return self.properties
        
    def get_properties_by_type(self, property_type: str) -> List[Dict]:
        """Get properties by type"""
        return [prop for prop in self.properties if prop.get('type', '').lower() == property_type.lower()]
        
    def get_properties_by_price_range(self, min_price: int, max_price: int) -> List[Dict]:
        """Get properties within price range"""
        return [prop for prop in self.properties 
                if min_price <= prop.get('price', 0) <= max_price]
                
    def get_properties_by_area_range(self, min_area: int, max_area: int) -> List[Dict]:
        """Get properties within area range"""
        return [prop for prop in self.properties 
                if min_area <= prop.get('area', 0) <= max_area]
                
    def get_property_stats(self) -> Dict:
        """Get property statistics"""
        if not self.properties:
            return {
                'total_properties': 0,
                'average_price': 0,
                'min_price': 0,
                'max_price': 0,
                'average_area': 0,
                'min_area': 0,
                'max_area': 0,
                'property_types': {}
            }
            
        prices = [prop.get('price', 0) for prop in self.properties]
        areas = [prop.get('area', 0) for prop in self.properties]
        
        # Count property types
        property_types = {}
        for prop in self.properties:
            prop_type = prop.get('type', 'نامشخص')
            property_types[prop_type] = property_types.get(prop_type, 0) + 1
        
        return {
            'total_properties': len(self.properties),
            'average_price': sum(prices) / len(prices) if prices else 0,
            'min_price': min(prices) if prices else 0,
            'max_price': max(prices) if prices else 0,
            'average_area': sum(areas) / len(areas) if areas else 0,
            'min_area': min(areas) if areas else 0,
            'max_area': max(areas) if areas else 0,
            'property_types': property_types
        }
        
    def bulk_add_properties(self, properties_list: List[Dict]) -> Dict:
        """Add multiple properties at once"""
        results = {
            'added': 0,
            'skipped': 0,
            'errors': []
        }
        
        for prop in properties_list:
            try:
                if self.add_property(prop):
                    results['added'] += 1
                else:
                    results['skipped'] += 1
                    results['errors'].append(f"Failed to add property {prop.get('code', 'unknown')}")
            except Exception as e:
                results['skipped'] += 1
                results['errors'].append(f"Error adding property {prop.get('code', 'unknown')}: {str(e)}")
                
        return results
        
    def validate_property_data(self, property_data: Dict) -> List[str]:
        """Validate property data and return list of errors"""
        errors = []
        
        # Required fields
        required_fields = ['code', 'type', 'address', 'price', 'area', 'bedrooms']
        for field in required_fields:
            if field not in property_data or not property_data[field]:
                errors.append(f"فیلد {field} الزامی است")
                
        # Validate specific fields
        if 'price' in property_data:
            try:
                price = int(property_data['price'])
                if price <= 0:
                    errors.append("قیمت باید مثبت باشد")
            except (ValueError, TypeError):
                errors.append("قیمت باید عدد باشد")
                
        if 'area' in property_data:
            try:
                area = int(property_data['area'])
                if area <= 0:
                    errors.append("متراژ باید مثبت باشد")
            except (ValueError, TypeError):
                errors.append("متراژ باید عدد باشد")
                
        if 'bedrooms' in property_data:
            try:
                bedrooms = int(property_data['bedrooms'])
                if bedrooms < 0:
                    errors.append("تعداد اتاق خواب نمی‌تواند منفی باشد")
            except (ValueError, TypeError):
                errors.append("تعداد اتاق خواب باید عدد باشد")
                
        return errors
