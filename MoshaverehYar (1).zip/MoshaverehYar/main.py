#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Telegram Real Estate Bot for Eivan Properties
Main entry point for the bot application
"""

import os
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from bot_handlers import BotHandlers
from config import Config
from utils.logger import setup_logging

def main():
    """Main function to start the bot"""
    # Setup logging
    setup_logging()
    logger = logging.getLogger(__name__)
    
    # Get bot token from environment
    bot_token = os.getenv("TELEGRAM_BOT_TOKEN")
    if not bot_token:
        logger.error("TELEGRAM_BOT_TOKEN environment variable is required")
        return
    
    # Create application
    application = Application.builder().token(bot_token).build()
    
    # Initialize bot handlers
    bot_handlers = BotHandlers()
    
    # Add command handlers
    application.add_handler(CommandHandler("start", bot_handlers.start))
    application.add_handler(CommandHandler("help", bot_handlers.help_command))
    application.add_handler(CommandHandler("search", bot_handlers.search_command))
    application.add_handler(CommandHandler("register", bot_handlers.register_customer))
    application.add_handler(CommandHandler("report", bot_handlers.admin_report))
    
    # Admin commands
    application.add_handler(CommandHandler("customers", bot_handlers.admin_customers))
    application.add_handler(CommandHandler("stats", bot_handlers.admin_stats))
    application.add_handler(CommandHandler("add_property", bot_handlers.admin_add_property))
    application.add_handler(CommandHandler("edit_property", bot_handlers.admin_edit_property))
    application.add_handler(CommandHandler("delete_property", bot_handlers.admin_delete_property))
    application.add_handler(CommandHandler("list_properties", bot_handlers.admin_list_properties))
    application.add_handler(CommandHandler("edit_welcome", bot_handlers.admin_edit_welcome))
    application.add_handler(CommandHandler("edit_company", bot_handlers.admin_edit_company))
    application.add_handler(CommandHandler("edit_prompts", bot_handlers.admin_edit_prompts))
    application.add_handler(CommandHandler("export_data", bot_handlers.admin_export_data))
    application.add_handler(CommandHandler("backup", bot_handlers.admin_backup))
    application.add_handler(CommandHandler("settings", bot_handlers.admin_settings))
    application.add_handler(CommandHandler("addadmin", bot_handlers.admin_add_admin))
    application.add_handler(CommandHandler("removeadmin", bot_handlers.admin_remove_admin))
    application.add_handler(CommandHandler("listadmins", bot_handlers.admin_list_admins))
    application.add_handler(CommandHandler("edittexts", bot_handlers.admin_edit_texts))
    application.add_handler(CommandHandler("resettext", bot_handlers.admin_reset_text))
    application.add_handler(CommandHandler("uploadproperties", bot_handlers.admin_upload_properties))
    
    # Add message handler for text messages
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, bot_handlers.handle_message))
    
    # Add contact handler
    application.add_handler(MessageHandler(filters.CONTACT, bot_handlers.handle_contact))
    
    # Add document handler for file uploads
    application.add_handler(MessageHandler(filters.Document.ALL, bot_handlers.handle_document))
    
    logger.info("Starting Eivan Properties Telegram Bot...")
    
    # Start the bot
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
