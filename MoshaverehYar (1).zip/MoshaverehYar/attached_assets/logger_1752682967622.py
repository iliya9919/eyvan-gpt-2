#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Logging utilities for Telegram Real Estate Bot
"""

import logging
import os
from datetime import datetime
from config import Config

def setup_logging():
    """Setup logging configuration"""
    
    # Create logs directory if it doesn't exist
    log_dir = "logs"
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # Configure logging
    log_level = getattr(logging, Config.LOG_LEVEL.upper(), logging.INFO)
    
    # Create formatters
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    console_formatter = logging.Formatter(
        '%(levelname)s - %(name)s - %(message)s'
    )
    
    # Create handlers
    file_handler = logging.FileHandler(
        os.path.join(log_dir, Config.LOG_FILE), 
        encoding='utf-8'
    )
    file_handler.setLevel(log_level)
    file_handler.setFormatter(file_formatter)
    
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    console_handler.setFormatter(console_formatter)
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)
    
    # Reduce noise from external libraries
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("telegram").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    
    return root_logger

def get_logger(name: str) -> logging.Logger:
    """Get logger instance"""
    return logging.getLogger(name)

class BotLogger:
    """Bot-specific logger with additional functionality"""
    
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
        
    def log_user_interaction(self, user_id: int, action: str, message: str = ""):
        """Log user interaction"""
        self.logger.info(f"User {user_id} - {action}: {message}")
        
    def log_property_search(self, user_id: int, query: str, results_count: int):
        """Log property search"""
        self.logger.info(f"Property search - User {user_id} - Query: {query} - Results: {results_count}")
        
    def log_customer_registration(self, user_id: int, phone: str):
        """Log customer registration"""
        self.logger.info(f"Customer registered - User {user_id} - Phone: {phone}")
        
    def log_error(self, error: Exception, context: str = ""):
        """Log error with context"""
        self.logger.error(f"Error in {context}: {str(error)}", exc_info=True)
        
    def log_admin_action(self, user_id: int, action: str):
        """Log admin action"""
        self.logger.info(f"Admin action - User {user_id} - Action: {action}")
        
    def log_system_event(self, event: str, details: str = ""):
        """Log system event"""
        self.logger.info(f"System event - {event}: {details}")
