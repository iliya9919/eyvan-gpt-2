#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GPT Integration for Telegram Real Estate Bot
Handles AI-powered message processing and responses
"""

import json
import os
import logging
from typing import Dict, Optional
from openai import OpenAI

class GPTIntegration:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        self.model = "gpt-4o"
        
        # Initialize OpenAI client
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            self.logger.warning("OPENAI_API_KEY not found. GPT features will be disabled.")
            self.client = None
        else:
            self.client = OpenAI(api_key=api_key)
            
    async def process_user_message(self, message: str, user_id: int = None) -> Dict:
        """Process user message and return intelligent response"""
        if not self.client:
            return {
                "response": "متاسفانه سرویس هوش مصنوعی در دسترس نیست. لطفاً از دستورات معمولی استفاده کنید.",
                "action": None
            }
            
        try:
            # Create system prompt for real estate assistant
            system_prompt = """
            شما یک مشاور املاک حرفه‌ای هستید که در شرکت املاک ایوان کار می‌کنید.
            وظیفه شما کمک به مشتریان در زمینه املاک است و تمام مکالمات را مدیریت می‌کنید.
            
            قوانین پاسخ‌گویی:
            1. همیشه مودب، دوستانه و حرفه‌ای باشید
            2. از زبان فارسی استفاده کنید
            3. خودتان را به عنوان مشاور املاک ایوان معرفی کنید
            4. با مشتریان صمیمانه صحبت کنید
            5. همیشه سعی کنید کمک مفیدی ارائه دهید
            
            Actions موجود:
            - "search": جستجو در املاک
            - "show_property": نمایش ملک خاص (با property_code)
            - "register": ثبت نام مشتری
            - "contact_advisor": تماس با مشاور
            - null: پاسخ عمومی
            
            مثال‌های کاربردی:
            - اگر کسی سلام کرد، گرم جواب دهید
            - اگر کسی از شما پرسید، خودتان را معرفی کنید
            - اگر کسی به دنبال ملک است، action: "search" بگذارید
            - اگر کسی کد ملک گفت، action: "show_property" بگذارید
            - اگر کسی می‌خواهد ثبت نام کند، action: "register" بگذارید
            
            پاسخ را در فرمت JSON زیر ارائه دهید:
            {
                "response": "پاسخ شما به فارسی",
                "action": "search|show_property|register|contact_advisor|null",
                "query": "کلیدواژه جستجو یا null",
                "property_code": "کد ملک یا null"
            }
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": message}
                ],
                response_format={"type": "json_object"},
                max_tokens=500,
                temperature=0.7
            )
            
            result = json.loads(response.choices[0].message.content)
            return result
            
        except Exception as e:
            self.logger.error(f"Error processing message with GPT: {e}")
            return {
                "response": "متوجه نشدم. می‌توانید سوال خود را واضح‌تر بپرسید؟",
                "action": None
            }
    
    def update_system_prompt(self, new_prompt: str):
        """Update the system prompt for GPT"""
        self.system_prompt = new_prompt
            
    def analyze_property_query(self, query: str) -> Dict:
        """Analyze property search query"""
        if not self.client:
            return {"type": "general", "parameters": {}}
            
        try:
            system_prompt = """
            شما یک تحلیل‌گر درخواست‌های جستجوی املاک هستید.
            درخواست کاربر را تحلیل کنید و پارامترهای جستجو را استخراج کنید.
            
            پاسخ را در فرمت JSON زیر ارائه دهید:
            {
                "type": "نوع ملک (آپارتمان، خانه، تجاری، ...)",
                "price_range": {"min": حداقل قیمت, "max": حداکثر قیمت},
                "area_range": {"min": حداقل متراژ, "max": حداکثر متراژ},
                "bedrooms": تعداد اتاق خواب,
                "location": "منطقه مورد نظر",
                "keywords": ["کلیدواژه‌های مهم"]
            }
            """
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": query}
                ],
                response_format={"type": "json_object"},
                max_tokens=300,
                temperature=0.3
            )
            
            result = json.loads(response.choices[0].message.content)
            return result
            
        except Exception as e:
            self.logger.error(f"Error analyzing query: {e}")
            return {"type": "general", "parameters": {}}
            
    def generate_property_description(self, property_data: Dict) -> str:
        """Generate attractive property description"""
        if not self.client:
            return property_data.get('description', 'توضیحات موجود نیست')
            
        try:
            system_prompt = """
            شما یک نویسنده متخصص در توضیحات املاک هستید.
            بر اساس اطلاعات ملک، توضیحات جذاب و فروشنده‌ای بنویسید.
            
            توضیحات باید:
            1. به زبان فارسی باشد
            2. جذاب و تشویقی باشد
            3. ویژگی‌های مهم را برجسته کند
            4. حداکثر 200 کلمه باشد
            """
            
            property_info = json.dumps(property_data, ensure_ascii=False)
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"اطلاعات ملک: {property_info}"}
                ],
                max_tokens=300,
                temperature=0.8
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"Error generating description: {e}")
            return property_data.get('description', 'توضیحات موجود نیست')
            
    def suggest_similar_properties(self, property_code: str, all_properties: list) -> list:
        """Suggest similar properties based on given property"""
        if not self.client or not all_properties:
            return []
            
        try:
            # Find the reference property
            ref_property = None
            for prop in all_properties:
                if prop.get('code') == property_code:
                    ref_property = prop
                    break
                    
            if not ref_property:
                return []
                
            # Simple similarity based on type, price range, and area
            similar_properties = []
            ref_price = ref_property.get('price', 0)
            ref_area = ref_property.get('area', 0)
            ref_type = ref_property.get('type', '')
            
            for prop in all_properties:
                if prop.get('code') == property_code:
                    continue
                    
                # Check similarity criteria
                price_diff = abs(prop.get('price', 0) - ref_price) / ref_price if ref_price > 0 else 1
                area_diff = abs(prop.get('area', 0) - ref_area) / ref_area if ref_area > 0 else 1
                same_type = prop.get('type', '') == ref_type
                
                if price_diff < 0.3 and area_diff < 0.3 and same_type:
                    similar_properties.append(prop)
                    
            return similar_properties[:3]  # Return top 3 similar properties
            
        except Exception as e:
            self.logger.error(f"Error suggesting similar properties: {e}")
            return []
            
    def get_market_insights(self, properties: list) -> Dict:
        """Generate market insights from property data"""
        if not self.client or not properties:
            return {"insights": "اطلاعات کافی برای تحلیل بازار موجود نیست"}
            
        try:
            # Prepare market data
            market_data = {
                "total_properties": len(properties),
                "property_types": {},
                "price_ranges": [],
                "areas": []
            }
            
            for prop in properties:
                prop_type = prop.get('type', 'نامشخص')
                market_data["property_types"][prop_type] = market_data["property_types"].get(prop_type, 0) + 1
                market_data["price_ranges"].append(prop.get('price', 0))
                market_data["areas"].append(prop.get('area', 0))
                
            system_prompt = """
            شما یک تحلیل‌گر بازار املاک هستید.
            بر اساس داده‌های ارائه شده، تحلیل کوتاه و مفیدی از بازار املاک ارائه دهید.
            
            تحلیل باید شامل:
            1. وضعیت کلی بازار
            2. قیمت‌های متوسط
            3. نوع املاک پرطرفدار
            4. توصیه‌هایی برای خریداران
            
            پاسخ به فارسی و حداکثر 300 کلمه باشد.
            """
            
            data_str = json.dumps(market_data, ensure_ascii=False)
            
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"داده‌های بازار: {data_str}"}
                ],
                max_tokens=400,
                temperature=0.6
            )
            
            return {"insights": response.choices[0].message.content}
            
        except Exception as e:
            self.logger.error(f"Error generating market insights: {e}")
            return {"insights": "خطا در تولید گزارش بازار"}
