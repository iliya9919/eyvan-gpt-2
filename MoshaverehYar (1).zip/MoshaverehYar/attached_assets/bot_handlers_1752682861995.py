#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bot handlers for Telegram Real Estate Bot
Handles all user interactions and bot commands
"""

import logging
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import ContextTypes
from property_manager import PropertyManager
from customer_manager import CustomerManager
from gpt_integration import GPTIntegration
from config import Config
import json
import re

class BotHandlers:
    def __init__(self):
        self.property_manager = PropertyManager()
        self.customer_manager = CustomerManager()
        self.gpt_integration = GPTIntegration()
        self.logger = logging.getLogger(__name__)
        
    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /start command"""
        user = update.effective_user
        welcome_message = f"""
🏠 سلام {user.first_name}! 
به چت‌بات املاک ایوان خوش آمدید.

من مشاور املاک شما هستم و می‌توانم به شما کمک کنم:

🔍 جستجو در املاک موجود
📋 ثبت اطلاعات شما به عنوان مشتری
📊 دریافت اطلاعات کامل واحدهای مسکونی

برای شروع:
• کد ملک را ارسال کنید
• از دستور /search برای جستجو استفاده کنید
• از دستور /register برای ثبت نام استفاده کنید

چطور می‌توانم کمکتان کنم؟
        """
        
        # Create reply keyboard
        keyboard = [
            [KeyboardButton("🔍 جستجو املاک"), KeyboardButton("📋 ثبت نام")],
            [KeyboardButton("📞 تماس با مشاور"), KeyboardButton("❓ راهنما")]
        ]
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
        
        await update.message.reply_text(welcome_message, reply_markup=reply_markup)
        
        # Log user interaction
        self.logger.info(f"User {user.id} started the bot")
        
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /help command"""
        user = update.effective_user
        
        if Config.is_admin(user.id):
            help_text = """
🔧 راهنمای مدیریت چت‌بات املاک ایوان:

📊 گزارش‌ها:
• /report - گزارش درخواست‌های مشتریان
• /customers - لیست مشتریان
• /stats - آمار کلی سیستم

🏠 مدیریت املاک:
• /add_property - اضافه کردن ملک جدید
• /edit_property [کد] - ویرایش ملک
• /delete_property [کد] - حذف ملک
• /list_properties - لیست همه املاک

💬 مدیریت متن‌ها:
• /edit_welcome - تغییر پیام خوش‌آمدگویی
• /edit_company - تغییر اطلاعات شرکت
• /edit_prompts - تغییر prompt های GPT

📤 صادرات:
• /export_data - دانلود اطلاعات CSV
• /backup - پشتیبان‌گیری از داده‌ها

⚙️ تنظیمات:
• /settings - تنظیمات سیستم
• /add_admin [user_id] - اضافه کردن مدیر
• /restart_bot - راه‌اندازی مجدد

📋 کاربران عادی:
• /search - جستجو املاک
• /register - ثبت نام
• ارسال کد ملک یا سوال
            """
        else:
            help_text = """
📋 راهنمای استفاده از چت‌بات املاک ایوان:

🔍 جستجو املاک:
• /search - شروع جستجو
• ارسال کد ملک (مثال: EV001)
• جستجو بر اساس قیمت، منطقه، نوع ملک

📋 ثبت اطلاعات:
• /register - ثبت نام به عنوان مشتری

💬 پیام‌های عمومی:
• می‌توانید سوال‌های خود را به صورت طبیعی بپرسید
• از عبارات فارسی استفاده کنید

📞 تماس با مشاور: 09123456789
            """
        await update.message.reply_text(help_text)
        
    async def search_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /search command"""
        search_help = """
🔍 برای جستجو می‌توانید از روش‌های زیر استفاده کنید:

1️⃣ جستجو با کد ملک:
   مثال: EV001

2️⃣ جستجو بر اساس قیمت:
   مثال: "قیمت زیر 500 میلیون"

3️⃣ جستجو بر اساس منطقه:
   مثال: "منطقه 1 تهران"

4️⃣ جستجو بر اساس نوع ملک:
   مثال: "آپارتمان 2 خواب"

5️⃣ جستجو ترکیبی:
   مثال: "آپارتمان در منطقه 3 تا 800 میلیون"

لطفاً درخواست خود را ارسال کنید:
        """
        await update.message.reply_text(search_help)
        
    async def register_customer(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle /register command"""
        user = update.effective_user
        
        # Check if user is already registered
        if self.customer_manager.is_customer_registered(user.id):
            await update.message.reply_text("شما قبلاً ثبت نام کرده‌اید. ✅")
            return
            
        register_text = """
📋 ثبت نام در سیستم املاک ایوان

برای ثبت نام، لطفاً روی دکمه زیر کلیک کنید تا شماره تماس خود را ارسال کنید.

یا می‌توانید به صورت دستی اطلاعات زیر را ارسال کنید:
• نام و نام خانوادگی
• شماره تماس
• نوع ملک مورد نظر (خرید/اجاره)
• بودجه تقریبی
• منطقه مورد نظر
        """
        
        # Create contact keyboard
        keyboard = [
            [KeyboardButton("📞 ارسال شماره تماس", request_contact=True)],
            [KeyboardButton("🏠 بازگشت به منوی اصلی")]
        ]
        reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)
        
        await update.message.reply_text(register_text, reply_markup=reply_markup)
        
    async def handle_contact(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle contact sharing"""
        user = update.effective_user
        contact = update.message.contact
        
        # Register customer with contact info
        customer_data = {
            "user_id": user.id,
            "first_name": user.first_name,
            "last_name": user.last_name,
            "username": user.username,
            "phone_number": contact.phone_number,
            "registration_date": None  # Will be set by customer_manager
        }
        
        success = self.customer_manager.register_customer(customer_data)
        
        if success:
            await update.message.reply_text(
                f"✅ ثبت نام موفق!\n\n"
                f"نام: {user.first_name} {user.last_name or ''}\n"
                f"شماره تماس: {contact.phone_number}\n\n"
                f"اطلاعات شما در سیستم ثبت شد.\n"
                f"مشاور ما به زودی با شما تماس خواهد گرفت."
            )
        else:
            await update.message.reply_text("❌ خطا در ثبت نام. لطفاً دوباره تلاش کنید.")
            
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle text messages"""
        user = update.effective_user
        message_text = update.message.text
        
        self.logger.info(f"User {user.id} sent message: {message_text}")
        
        # Log customer request
        self.customer_manager.log_customer_request(user.id, message_text)
        
        # Check if message is a property code
        if self.is_property_code(message_text):
            await self.handle_property_code(update, context, message_text)
            return
            
        # Check for button presses
        if message_text == "🔍 جستجو املاک":
            await self.search_command(update, context)
            return
        elif message_text == "📋 ثبت نام":
            await self.register_customer(update, context)
            return
        elif message_text == "📞 تماس با مشاور":
            await update.message.reply_text(
                "📞 تماس با مشاور املاک ایوان:\n\n"
                "شماره تماس: 09123456789\n"
                "ساعات کاری: 9 صبح تا 18 عصر\n"
                "آدرس: تهران، میدان ونک، برج ایوان"
            )
            return
        elif message_text == "❓ راهنما":
            await self.help_command(update, context)
            return
        elif message_text == "🏠 بازگشت به منوی اصلی":
            await self.start(update, context)
            return
        
        # Handle admin data processing
        if Config.is_admin(user.id):
            admin_handled = await self.handle_admin_data(update, context, message_text)
            if admin_handled:
                return
        
        # Use GPT for ALL message processing - let GPT handle everything
        try:
            response = await self.gpt_integration.process_user_message(message_text, user.id)
            
            # Handle different actions from GPT
            action = response.get("action")
            if action == "search":
                search_results = self.property_manager.search_properties(response.get("query", ""))
                await self.send_search_results(update, search_results)
            elif action == "show_property":
                property_code = response.get("property_code")
                if property_code:
                    await self.handle_property_code(update, context, property_code)
                else:
                    await update.message.reply_text(response.get("response", "کد ملک مشخص نشده است."))
            elif action == "register":
                await self.register_customer(update, context)
            elif action == "contact_advisor":
                await update.message.reply_text(
                    "📞 تماس با مشاور املاک ایوان:\n\n"
                    "شماره تماس: 09123456789\n"
                    "ساعات کاری: 9 صبح تا 18 عصر\n"
                    "آدرس: تهران، میدان ونک، برج ایوان"
                )
            else:
                # Default response from GPT
                await update.message.reply_text(response.get("response", "متوجه نشدم. لطفاً دوباره تلاش کنید."))
                
        except Exception as e:
            self.logger.error(f"Error processing message: {e}")
            await update.message.reply_text(
                "متاسفانه در پردازش پیام شما خطایی رخ داد. لطفاً دوباره تلاش کنید یا با مشاور تماس بگیرید."
            )
            
    def is_property_code(self, text: str) -> bool:
        """Check if text is a property code"""
        # Property codes start with EV followed by numbers
        pattern = r'^EV\d+$'
        return bool(re.match(pattern, text.upper()))
        
    async def handle_property_code(self, update: Update, context: ContextTypes.DEFAULT_TYPE, code: str) -> None:
        """Handle property code lookup"""
        property_info = self.property_manager.get_property_by_code(code.upper())
        
        if property_info:
            await self.send_property_info(update, property_info)
        else:
            await update.message.reply_text(
                f"❌ کد ملک {code} یافت نشد.\n\n"
                f"لطفاً کد را بررسی کنید یا از /search برای جستجو استفاده کنید."
            )
            
    async def send_property_info(self, update: Update, property_info: dict) -> None:
        """Send detailed property information"""
        message = f"""
🏠 **اطلاعات ملک {property_info['code']}**

📍 **آدرس:** {property_info['address']}
🏢 **نوع:** {property_info['type']}
🛏️ **تعداد اتاق:** {property_info['bedrooms']}
📐 **متراژ:** {property_info['area']} متر مربع
💰 **قیمت:** {property_info['price']:,} تومان
🏗️ **سال ساخت:** {property_info['year_built']}
🏠 **طبقه:** {property_info['floor']}

📋 **توضیحات:**
{property_info['description']}

📞 **برای بازدید و اطلاعات بیشتر:**
تماس: 09123456789
        """
        
        await update.message.reply_text(message, parse_mode='Markdown')
        
    async def send_search_results(self, update: Update, results: list) -> None:
        """Send search results to user"""
        if not results:
            await update.message.reply_text("❌ هیچ ملکی با مشخصات مورد نظر یافت نشد.")
            return
            
        message = f"🔍 **نتایج جستجو ({len(results)} ملک):**\n\n"
        
        for i, prop in enumerate(results[:5], 1):  # Show max 5 results
            message += f"{i}. **{prop['code']}** - {prop['type']}\n"
            message += f"   📍 {prop['address']}\n"
            message += f"   💰 {prop['price']:,} تومان\n"
            message += f"   📐 {prop['area']} متر - {prop['bedrooms']} اتاق\n\n"
            
        if len(results) > 5:
            message += f"... و {len(results) - 5} ملک دیگر\n\n"
            
        message += "برای اطلاعات کامل هر ملک، کد آن را ارسال کنید."
        
        await update.message.reply_text(message, parse_mode='Markdown')
        
    async def admin_report(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin reports (only for authorized users)"""
        user = update.effective_user
        
        # Check if user is admin (you can add admin user IDs to config)
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
            
        # Get customer requests report
        report = self.customer_manager.get_requests_report()
        
        if not report:
            await update.message.reply_text("📊 هیچ درخواستی ثبت نشده است.")
            return
            
        message = "📊 **گزارش درخواست‌های مشتریان:**\n\n"
        
        for request in report[-10:]:  # Show last 10 requests
            message += f"👤 **{request['user_name']}**\n"
            message += f"📱 {request.get('phone', 'ثبت نشده')}\n"
            message += f"💬 {request['message']}\n"
            message += f"⏰ {request['timestamp']}\n\n"
            
        await update.message.reply_text(message, parse_mode='Markdown')
        
    async def admin_customers(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin customers list"""
        user = update.effective_user
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
        
        customers = self.customer_manager.get_all_customers()
        if not customers:
            await update.message.reply_text("📊 هیچ مشتری ثبت نشده است.")
            return
        
        message = "👥 **لیست مشتریان:**\n\n"
        for customer in customers[-10:]:  # Show last 10 customers
            message += f"👤 **{customer.get('first_name', '')} {customer.get('last_name', '')}**\n"
            message += f"📱 {customer.get('phone_number', 'ثبت نشده')}\n"
            message += f"🆔 {customer.get('user_id', 'نامشخص')}\n"
            message += f"📅 {customer.get('registration_date', 'نامشخص')}\n\n"
        
        await update.message.reply_text(message, parse_mode='Markdown')
        
    async def admin_stats(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin statistics"""
        user = update.effective_user
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
        
        customer_stats = self.customer_manager.get_customer_stats()
        property_stats = self.property_manager.get_property_stats()
        
        message = f"""
📊 **آمار کلی سیستم:**

👥 **مشتریان:**
• تعداد کل: {customer_stats.get('total_customers', 0)}
• فعال: {customer_stats.get('active_customers', 0)}

📋 **درخواست‌ها:**
• تعداد کل: {customer_stats.get('total_requests', 0)}
• در انتظار: {customer_stats.get('pending_requests', 0)}

🏠 **املاک:**
• تعداد کل: {property_stats.get('total_properties', 0)}
• میانگین قیمت: {property_stats.get('average_price', 0):,.0f} تومان
• میانگین متراژ: {property_stats.get('average_area', 0):.0f} متر مربع
        """
        
        await update.message.reply_text(message, parse_mode='Markdown')
        
    async def admin_add_property(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin add property command"""
        user = update.effective_user
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
        
        await update.message.reply_text("""
🏠 **اضافه کردن ملک جدید:**

لطفاً اطلاعات ملک را به صورت زیر ارسال کنید:

```
کد: EV007
نوع: آپارتمان
آدرس: تهران، منطقه 1، خیابان نمونه
قیمت: 800000000
متراژ: 85
اتاق: 2
سال: 1400
طبقه: 3
توضیحات: توضیحات ملک
```

یا از فرمت JSON استفاده کنید:
```json
{
  "code": "EV007",
  "type": "آپارتمان",
  "address": "تهران، منطقه 1، خیابان نمونه",
  "price": 800000000,
  "area": 85,
  "bedrooms": 2,
  "year_built": 1400,
  "floor": 3,
  "description": "توضیحات ملک"
}
```
        """, parse_mode='Markdown')
        
    async def admin_edit_property(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin edit property command"""
        user = update.effective_user
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
        
        if not context.args:
            await update.message.reply_text("❌ لطفاً کد ملک را وارد کنید:\n`/edit_property EV001`", parse_mode='Markdown')
            return
        
        property_code = context.args[0].upper()
        property_info = self.property_manager.get_property_by_code(property_code)
        
        if not property_info:
            await update.message.reply_text(f"❌ ملک با کد {property_code} یافت نشد.")
            return
        
        await update.message.reply_text(f"""
✏️ **ویرایش ملک {property_code}:**

اطلاعات فعلی:
```json
{json.dumps(property_info, ensure_ascii=False, indent=2)}
```

برای ویرایش، اطلاعات جدید را در فرمت JSON ارسال کنید.
        """, parse_mode='Markdown')
        
    async def admin_delete_property(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin delete property command"""
        user = update.effective_user
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
        
        if not context.args:
            await update.message.reply_text("❌ لطفاً کد ملک را وارد کنید:\n`/delete_property EV001`", parse_mode='Markdown')
            return
        
        property_code = context.args[0].upper()
        
        if self.property_manager.delete_property(property_code):
            await update.message.reply_text(f"✅ ملک {property_code} با موفقیت حذف شد.")
        else:
            await update.message.reply_text(f"❌ خطا در حذف ملک {property_code}.")
            
    async def admin_list_properties(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin list properties command"""
        user = update.effective_user
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
        
        properties = self.property_manager.get_all_properties()
        if not properties:
            await update.message.reply_text("📊 هیچ ملکی ثبت نشده است.")
            return
        
        message = "🏠 **لیست املاک:**\n\n"
        for prop in properties:
            message += f"**{prop['code']}** - {prop['type']}\n"
            message += f"📍 {prop['address']}\n"
            message += f"💰 {prop['price']:,} تومان\n"
            message += f"📐 {prop['area']} متر - {prop['bedrooms']} اتاق\n\n"
        
        await update.message.reply_text(message, parse_mode='Markdown')
        
    async def admin_edit_welcome(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin edit welcome message"""
        user = update.effective_user
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
        
        current_message = Config.WELCOME_MESSAGE
        await update.message.reply_text(f"""
📝 **تغییر پیام خوش‌آمدگویی:**

پیام فعلی:
```
{current_message}
```

برای تغییر، پیام جدید را ارسال کنید.
        """, parse_mode='Markdown')
        
    async def admin_edit_company(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin edit company info"""
        user = update.effective_user
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
        
        await update.message.reply_text(f"""
🏢 **اطلاعات شرکت فعلی:**

نام: {Config.COMPANY_NAME}
تلفن: {Config.COMPANY_PHONE}
آدرس: {Config.COMPANY_ADDRESS}
ساعات کاری: {Config.WORKING_HOURS}

برای تغییر، اطلاعات جدید را در فرمت JSON ارسال کنید:
```json
{{
  "name": "نام شرکت",
  "phone": "شماره تلفن",
  "address": "آدرس",
  "working_hours": "ساعات کاری"
}}
```
        """, parse_mode='Markdown')
        
    async def admin_edit_prompts(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin edit GPT prompts"""
        user = update.effective_user
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
        
        await update.message.reply_text("""
🤖 **تغییر Prompt های GPT:**

برای تغییر prompt اصلی GPT، پیام زیر را ارسال کنید:

```
PROMPT_UPDATE:
prompt جدید شما...
```

Prompt فعلی در فایل `gpt_integration.py` قرار دارد.
        """, parse_mode='Markdown')
        
    async def admin_export_data(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin export data command"""
        user = update.effective_user
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
        
        try:
            # Export all data
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            # Export customers
            customers_file = f"customers_export_{timestamp}.csv"
            self.customer_manager.export_customers_csv(customers_file)
            
            # Export requests
            requests_file = f"requests_export_{timestamp}.csv"
            self.customer_manager.export_requests_csv(requests_file)
            
            await update.message.reply_text(f"""
📤 **صادرات داده‌ها:**

فایل‌های CSV ایجاد شدند:
• {customers_file}
• {requests_file}

برای دانلود، از سرور استفاده کنید.
            """)
            
        except Exception as e:
            await update.message.reply_text(f"❌ خطا در صادرات داده‌ها: {str(e)}")
            
    async def admin_backup(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin backup command"""
        user = update.effective_user
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
        
        await update.message.reply_text("""
💾 **پشتیبان‌گیری:**

فایل‌های داده در مسیر `data/` قرار دارند:
• properties.json
• customers.json
• requests.json

برای پشتیبان‌گیری کامل، این فایل‌ها را کپی کنید.
        """)
        
    async def admin_settings(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin settings command"""
        user = update.effective_user
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
        
        await update.message.reply_text(f"""
⚙️ **تنظیمات سیستم:**

مدیران فعلی: {Config.ADMIN_USER_IDS}
حداکثر نتایج جستجو: {Config.MAX_SEARCH_RESULTS}
سطح لاگ: {Config.LOG_LEVEL}

برای تغییر تنظیمات، فایل `config.py` را ویرایش کنید.
        """)
        
    async def admin_add_admin(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle admin add admin command"""
        user = update.effective_user
        if user.id not in Config.ADMIN_USER_IDS:
            await update.message.reply_text("❌ شما مجاز به دسترسی به این بخش نیستید.")
            return
        
        if not context.args:
            await update.message.reply_text("❌ لطفاً user_id را وارد کنید:\n`/add_admin 123456789`", parse_mode='Markdown')
            return
        
        try:
            new_admin_id = int(context.args[0])
            if new_admin_id not in Config.ADMIN_USER_IDS:
                await update.message.reply_text(f"""
✅ **مدیر جدید اضافه شد:**

User ID: {new_admin_id}

برای اعمال تغییرات، فایل `config.py` را به روز کنید.
                """)
            else:
                await update.message.reply_text(f"❌ کاربر {new_admin_id} قبلاً مدیر است.")
                
        except ValueError:
            await update.message.reply_text("❌ لطفاً یک عدد معتبر وارد کنید.")
            
    async def handle_admin_data(self, update: Update, context: ContextTypes.DEFAULT_TYPE, message_text: str) -> bool:
        """Handle admin data input (property addition, prompt updates, etc.)"""
        user = update.effective_user
        
        # Handle prompt updates
        if message_text.startswith("PROMPT_UPDATE:"):
            new_prompt = message_text.replace("PROMPT_UPDATE:", "").strip()
            await self.update_gpt_prompt(update, new_prompt)
            return True
        
        # Handle JSON data for property addition/editing
        if message_text.startswith("{") and message_text.endswith("}"):
            try:
                import json
                data = json.loads(message_text)
                
                # Check if it's property data
                if "code" in data and "type" in data:
                    if self.property_manager.add_property(data):
                        await update.message.reply_text(f"✅ ملک {data['code']} با موفقیت اضافه شد.")
                    else:
                        await update.message.reply_text(f"❌ خطا در اضافه کردن ملک {data['code']}.")
                    return True
                
                # Check if it's company info update
                elif "name" in data and "phone" in data:
                    await self.update_company_info(update, data)
                    return True
                    
            except json.JSONDecodeError:
                await update.message.reply_text("❌ فرمت JSON نامعتبر است.")
                return True
        
        # Handle property data in text format
        if "کد:" in message_text and "نوع:" in message_text:
            await self.parse_property_text(update, message_text)
            return True
            
        return False
    
    async def update_gpt_prompt(self, update: Update, new_prompt: str):
        """Update GPT prompt"""
        try:
            # Update the prompt in gpt_integration
            self.gpt_integration.update_system_prompt(new_prompt)
            await update.message.reply_text("✅ Prompt GPT با موفقیت به روز شد.")
        except Exception as e:
            await update.message.reply_text(f"❌ خطا در به روز رسانی prompt: {str(e)}")
    
    async def update_company_info(self, update: Update, data: dict):
        """Update company information"""
        try:
            # This would typically update a config file or database
            # For now, just confirm the update
            await update.message.reply_text("✅ اطلاعات شرکت به روز شد. برای اعمال تغییرات، فایل config.py را ویرایش کنید.")
        except Exception as e:
            await update.message.reply_text(f"❌ خطا در به روز رسانی اطلاعات شرکت: {str(e)}")
    
    async def parse_property_text(self, update: Update, message_text: str):
        """Parse property data from text format"""
        try:
            lines = message_text.strip().split('\n')
            property_data = {}
            
            for line in lines:
                if ':' in line:
                    key, value = line.split(':', 1)
                    key = key.strip()
                    value = value.strip()
                    
                    if key == "کد":
                        property_data["code"] = value.upper()
                    elif key == "نوع":
                        property_data["type"] = value
                    elif key == "آدرس":
                        property_data["address"] = value
                    elif key == "قیمت":
                        property_data["price"] = int(value)
                    elif key == "متراژ":
                        property_data["area"] = int(value)
                    elif key == "اتاق":
                        property_data["bedrooms"] = int(value)
                    elif key == "سال":
                        property_data["year_built"] = int(value)
                    elif key == "طبقه":
                        property_data["floor"] = int(value)
                    elif key == "توضیحات":
                        property_data["description"] = value
            
            if self.property_manager.add_property(property_data):
                await update.message.reply_text(f"✅ ملک {property_data['code']} با موفقیت اضافه شد.")
            else:
                await update.message.reply_text(f"❌ خطا در اضافه کردن ملک.")
                
        except Exception as e:
            await update.message.reply_text(f"❌ خطا در پردازش اطلاعات ملک: {str(e)}")
    
    async def handle_document(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        """Handle document uploads (CSV, JSON files)"""
        user = update.effective_user
        
        if not Config.is_admin(user.id):
            await update.message.reply_text("❌ شما مجاز به آپلود فایل نیستید.")
            return
        
        document = update.message.document
        file_name = document.file_name
        
        if not file_name.endswith(('.csv', '.json')):
            await update.message.reply_text("❌ فقط فایل‌های CSV و JSON پشتیبانی می‌شوند.")
            return
        
        try:
            # Download the file
            file = await context.bot.get_file(document.file_id)
            await file.download_to_drive(f"uploads/{file_name}")
            
            await update.message.reply_text(f"✅ فایل {file_name} با موفقیت آپلود شد.")
            
        except Exception as e:
            await update.message.reply_text(f"❌ خطا در آپلود فایل: {str(e)}")
