#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Configuration settings for Telegram Real Estate Bot
"""

import os
from typing import List

class Config:
    """Configuration class for the bot"""
    
    # Bot settings
    BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
    WEBHOOK_URL = os.getenv("WEBHOOK_URL", "")
    
    # OpenAI settings
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    
    # Admin user IDs (add your admin Telegram user IDs here)
    ADMIN_USER_IDS: List[int] = [
        1309021297,  # Your user ID from the logs
        # Add more admin user IDs here if needed
    ]
    
    # File paths
    DATA_DIR = "data"
    PROPERTIES_FILE = os.path.join(DATA_DIR, "properties.json")
    CUSTOMERS_FILE = os.path.join(DATA_DIR, "customers.json")
    REQUESTS_FILE = os.path.join(DATA_DIR, "requests.json")
    
    # Logging settings
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE = "bot.log"
    
    # Bot behavior settings
    MAX_SEARCH_RESULTS = 10
    MESSAGE_CACHE_SIZE = 1000
    
    # Business information
    COMPANY_NAME = "املاک ایوان"
    COMPANY_PHONE = "09123456789"
    COMPANY_ADDRESS = "تهران، میدان ونک، برج ایوان"
    WORKING_HOURS = "9 صبح تا 18 عصر"
    
    # Messages
    WELCOME_MESSAGE = """
🏠 سلام! به چت‌بات املاک ایوان خوش آمدید.

من مشاور املاک شما هستم و می‌توانم کمکتان کنم:
🔍 جستجو در املاک موجود
📋 ثبت اطلاعات شما
📊 دریافت اطلاعات کامل املاک

چطور می‌توانم کمکتان کنم؟
    """
    
    ERROR_MESSAGE = "متاسفانه خطایی رخ داد. لطفاً دوباره تلاش کنید."
    
    # Rate limiting
    RATE_LIMIT_MESSAGES = 10  # messages per minute
    RATE_LIMIT_WINDOW = 60    # seconds
    
    # Database settings (for future use)
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///bot.db")
    
    @classmethod
    def get_admin_ids(cls) -> List[int]:
        """Get admin user IDs from environment or config"""
        env_admins = os.getenv("ADMIN_USER_IDS", "")
        if env_admins:
            try:
                return [int(uid.strip()) for uid in env_admins.split(",") if uid.strip()]
            except ValueError:
                pass
        return cls.ADMIN_USER_IDS
    
    @classmethod
    def is_admin(cls, user_id: int) -> bool:
        """Check if user is admin"""
        return user_id in cls.get_admin_ids()
    
    @classmethod
    def validate_config(cls) -> bool:
        """Validate configuration"""
        if not cls.BOT_TOKEN:
            print("Error: TELEGRAM_BOT_TOKEN is required")
            return False
            
        return True
