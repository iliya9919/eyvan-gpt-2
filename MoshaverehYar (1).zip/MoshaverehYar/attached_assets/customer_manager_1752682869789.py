#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Customer Manager for Telegram Real Estate Bot
Handles customer registration and request tracking
"""

import json
import os
import logging
from typing import List, Dict, Optional
from datetime import datetime

class CustomerManager:
    def __init__(self, customers_file: str = "data/customers.json", requests_file: str = "data/requests.json"):
        self.customers_file = customers_file
        self.requests_file = requests_file
        self.logger = logging.getLogger(__name__)
        self.customers = self.load_customers()
        self.requests = self.load_requests()
        
    def load_customers(self) -> List[Dict]:
        """Load customers from JSON file"""
        try:
            if os.path.exists(self.customers_file):
                with open(self.customers_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                os.makedirs(os.path.dirname(self.customers_file), exist_ok=True)
                return []
        except Exception as e:
            self.logger.error(f"Error loading customers: {e}")
            return []
            
    def save_customers(self) -> bool:
        """Save customers to JSON file"""
        try:
            with open(self.customers_file, 'w', encoding='utf-8') as f:
                json.dump(self.customers, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            self.logger.error(f"Error saving customers: {e}")
            return False
            
    def load_requests(self) -> List[Dict]:
        """Load customer requests from JSON file"""
        try:
            if os.path.exists(self.requests_file):
                with open(self.requests_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                os.makedirs(os.path.dirname(self.requests_file), exist_ok=True)
                return []
        except Exception as e:
            self.logger.error(f"Error loading requests: {e}")
            return []
            
    def save_requests(self) -> bool:
        """Save requests to JSON file"""
        try:
            with open(self.requests_file, 'w', encoding='utf-8') as f:
                json.dump(self.requests, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            self.logger.error(f"Error saving requests: {e}")
            return False
            
    def register_customer(self, customer_data: Dict) -> bool:
        """Register new customer"""
        try:
            # Check if customer already exists
            user_id = customer_data.get('user_id')
            if self.is_customer_registered(user_id):
                return False
                
            # Add registration timestamp
            customer_data['registration_date'] = datetime.now().isoformat()
            customer_data['status'] = 'active'
            
            self.customers.append(customer_data)
            success = self.save_customers()
            
            if success:
                self.logger.info(f"Customer registered: {user_id}")
                
            return success
            
        except Exception as e:
            self.logger.error(f"Error registering customer: {e}")
            return False
            
    def is_customer_registered(self, user_id: int) -> bool:
        """Check if customer is already registered"""
        return any(customer.get('user_id') == user_id for customer in self.customers)
        
    def get_customer_by_user_id(self, user_id: int) -> Optional[Dict]:
        """Get customer by user ID"""
        for customer in self.customers:
            if customer.get('user_id') == user_id:
                return customer
        return None
        
    def update_customer(self, user_id: int, updates: Dict) -> bool:
        """Update customer information"""
        try:
            for i, customer in enumerate(self.customers):
                if customer.get('user_id') == user_id:
                    self.customers[i].update(updates)
                    self.customers[i]['updated_at'] = datetime.now().isoformat()
                    return self.save_customers()
            return False
        except Exception as e:
            self.logger.error(f"Error updating customer: {e}")
            return False
            
    def log_customer_request(self, user_id: int, message: str) -> bool:
        """Log customer request"""
        try:
            # Get customer info
            customer = self.get_customer_by_user_id(user_id)
            
            request_data = {
                'user_id': user_id,
                'user_name': f"{customer.get('first_name', '')} {customer.get('last_name', '')}" if customer else 'Unknown',
                'phone': customer.get('phone_number', '') if customer else '',
                'message': message,
                'timestamp': datetime.now().isoformat(),
                'status': 'pending'
            }
            
            self.requests.append(request_data)
            success = self.save_requests()
            
            if success:
                self.logger.info(f"Request logged for user {user_id}: {message[:50]}...")
                
            return success
            
        except Exception as e:
            self.logger.error(f"Error logging request: {e}")
            return False
            
    def get_requests_report(self) -> List[Dict]:
        """Get customer requests report"""
        return sorted(self.requests, key=lambda x: x.get('timestamp', ''), reverse=True)
        
    def get_customer_requests(self, user_id: int) -> List[Dict]:
        """Get requests for specific customer"""
        return [req for req in self.requests if req.get('user_id') == user_id]
        
    def mark_request_as_handled(self, request_index: int) -> bool:
        """Mark request as handled"""
        try:
            if 0 <= request_index < len(self.requests):
                self.requests[request_index]['status'] = 'handled'
                self.requests[request_index]['handled_at'] = datetime.now().isoformat()
                return self.save_requests()
            return False
        except Exception as e:
            self.logger.error(f"Error marking request as handled: {e}")
            return False
            
    def get_all_customers(self) -> List[Dict]:
        """Get all customers"""
        return self.customers
        
    def get_active_customers(self) -> List[Dict]:
        """Get active customers"""
        return [customer for customer in self.customers if customer.get('status') == 'active']
        
    def get_customer_stats(self) -> Dict:
        """Get customer statistics"""
        active_customers = self.get_active_customers()
        pending_requests = [req for req in self.requests if req.get('status') == 'pending']
        
        return {
            'total_customers': len(self.customers),
            'active_customers': len(active_customers),
            'total_requests': len(self.requests),
            'pending_requests': len(pending_requests),
            'registration_dates': [customer.get('registration_date') for customer in self.customers]
        }
        
    def export_customers_csv(self, filename: str) -> bool:
        """Export customers to CSV file"""
        try:
            import csv
            
            with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
                if not self.customers:
                    return True
                    
                fieldnames = self.customers[0].keys()
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                for customer in self.customers:
                    writer.writerow(customer)
                    
            return True
        except Exception as e:
            self.logger.error(f"Error exporting customers to CSV: {e}")
            return False
            
    def export_requests_csv(self, filename: str) -> bool:
        """Export requests to CSV file"""
        try:
            import csv
            
            with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
                if not self.requests:
                    return True
                    
                fieldnames = self.requests[0].keys()
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                for request in self.requests:
                    writer.writerow(request)
                    
            return True
        except Exception as e:
            self.logger.error(f"Error exporting requests to CSV: {e}")
            return False
