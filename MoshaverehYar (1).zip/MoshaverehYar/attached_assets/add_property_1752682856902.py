#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Add New Property to Database
"""

from property_manager import PropertyManager
from utils.validators import PropertyValidator

def add_property_interactive():
    """Interactive property adding"""
    
    property_manager = PropertyManager()
    
    print("🏠 اضافه کردن ملک جدید")
    print("=" * 40)
    
    # Get property data
    property_data = {}
    
    # Property code
    while True:
        code = input("کد ملک (مثال: EV007): ").strip()
        if PropertyValidator.validate_property_code(code):
            if not property_manager.get_property_by_code(code):
                property_data['code'] = code.upper()
                break
            else:
                print("❌ این کد قبلاً استفاده شده است")
        else:
            print("❌ کد باید در فرمت EV + اعداد باشد")
    
    # Property type
    valid_types = ['آپارتمان', 'خانه', 'ویلا', 'تجاری', 'اداری', 'صنعتی', 'زمین', 'باغ', 'مغازه', 'دفتر کار']
    print(f"نوع ملک ({', '.join(valid_types)}): ")
    while True:
        prop_type = input().strip()
        if PropertyValidator.validate_property_type(prop_type):
            property_data['type'] = prop_type
            break
        else:
            print("❌ نوع ملک نامعتبر است")
    
    # Address
    property_data['address'] = input("آدرس: ").strip()
    
    # Price
    while True:
        try:
            price = int(input("قیمت (تومان): "))
            if PropertyValidator.validate_price(price):
                property_data['price'] = price
                break
            else:
                print("❌ قیمت باید عدد مثبت باشد")
        except ValueError:
            print("❌ لطفاً عدد وارد کنید")
    
    # Area
    while True:
        try:
            area = int(input("متراژ (متر مربع): "))
            if PropertyValidator.validate_area(area):
                property_data['area'] = area
                break
            else:
                print("❌ متراژ باید عدد مثبت باشد")
        except ValueError:
            print("❌ لطفاً عدد وارد کنید")
    
    # Bedrooms
    while True:
        try:
            bedrooms = int(input("تعداد اتاق خواب: "))
            if PropertyValidator.validate_bedrooms(bedrooms):
                property_data['bedrooms'] = bedrooms
                break
            else:
                print("❌ تعداد اتاق خواب باید بین 0 تا 10 باشد")
        except ValueError:
            print("❌ لطفاً عدد وارد کنید")
    
    # Year built
    while True:
        try:
            year = int(input("سال ساخت (مثال: 1400): "))
            if 1350 <= year <= 1410:
                property_data['year_built'] = year
                break
            else:
                print("❌ سال ساخت باید بین 1350 تا 1410 باشد")
        except ValueError:
            print("❌ لطفاً عدد وارد کنید")
    
    # Floor
    while True:
        try:
            floor = int(input("طبقه: "))
            if -2 <= floor <= 50:
                property_data['floor'] = floor
                break
            else:
                print("❌ طبقه باید بین -2 تا 50 باشد")
        except ValueError:
            print("❌ لطفاً عدد وارد کنید")
    
    # Description
    property_data['description'] = input("توضیحات: ").strip()
    
    # Validate and add
    errors = PropertyValidator.validate_property_data(property_data)
    if errors:
        print("❌ خطاها:")
        for field, error in errors.items():
            print(f"  - {field}: {error}")
        return
    
    # Add to database
    if property_manager.add_property(property_data):
        print(f"✅ ملک {property_data['code']} با موفقیت اضافه شد")
        
        # Show summary
        print("\n📋 خلاصه اطلاعات:")
        print(f"کد: {property_data['code']}")
        print(f"نوع: {property_data['type']}")
        print(f"آدرس: {property_data['address']}")
        print(f"قیمت: {property_data['price']:,} تومان")
        print(f"متراژ: {property_data['area']} متر مربع")
        print(f"تعداد اتاق: {property_data['bedrooms']}")
        print(f"سال ساخت: {property_data['year_built']}")
        print(f"طبقه: {property_data['floor']}")
        print(f"توضیحات: {property_data['description']}")
        
    else:
        print("❌ خطا در اضافه کردن ملک")

def add_property_from_data(property_data):
    """Add property from data dictionary"""
    
    property_manager = PropertyManager()
    
    # Validate
    errors = PropertyValidator.validate_property_data(property_data)
    if errors:
        print("❌ خطاها:")
        for field, error in errors.items():
            print(f"  - {field}: {error}")
        return False
    
    # Add to database
    if property_manager.add_property(property_data):
        print(f"✅ ملک {property_data['code']} با موفقیت اضافه شد")
        return True
    else:
        print("❌ خطا در اضافه کردن ملک")
        return False

if __name__ == "__main__":
    add_property_interactive()