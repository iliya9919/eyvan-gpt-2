#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Export Customer Data and Requests to CSV
"""

import json
import csv
from datetime import datetime
from customer_manager import CustomerManager
from property_manager import PropertyManager

def export_all_data():
    """Export all customer data and requests"""
    
    # Initialize managers
    customer_manager = CustomerManager()
    property_manager = PropertyManager()
    
    # Current timestamp for filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Export customers
    customers_filename = f"customers_export_{timestamp}.csv"
    if customer_manager.export_customers_csv(customers_filename):
        print(f"✅ Customer data exported to: {customers_filename}")
    else:
        print("❌ Failed to export customers")
    
    # Export requests
    requests_filename = f"requests_export_{timestamp}.csv"
    if customer_manager.export_requests_csv(requests_filename):
        print(f"✅ Requests data exported to: {requests_filename}")
    else:
        print("❌ Failed to export requests")
    
    # Export properties
    properties_filename = f"properties_export_{timestamp}.csv"
    properties = property_manager.get_all_properties()
    
    if properties:
        with open(properties_filename, 'w', newline='', encoding='utf-8') as csvfile:
            fieldnames = properties[0].keys()
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for prop in properties:
                writer.writerow(prop)
        print(f"✅ Properties data exported to: {properties_filename}")
    else:
        print("❌ No properties to export")
    
    # Print summary
    print("\n📊 Summary:")
    print(f"Total customers: {len(customer_manager.customers)}")
    print(f"Total requests: {len(customer_manager.requests)}")
    print(f"Total properties: {len(properties)}")

if __name__ == "__main__":
    export_all_data()