#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Customer Manager for Telegram Real Estate Bot
Handles customer registration and request tracking
"""

import json
import os
import logging
from typing import List, Dict, Optional
from datetime import datetime

class CustomerManager:
    def __init__(self, customers_file: str = "data/customers.json", requests_file: str = "data/requests.json"):
        self.customers_file = customers_file
        self.requests_file = requests_file
        self.logger = logging.getLogger(__name__)
        self.customers = self.load_customers()
        self.requests = self.load_requests()
        
    def load_customers(self) -> List[Dict]:
        """Load customers from JSON file"""
        try:
            if os.path.exists(self.customers_file):
                with open(self.customers_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                os.makedirs(os.path.dirname(self.customers_file), exist_ok=True)
                return []
        except Exception as e:
            self.logger.error(f"Error loading customers: {e}")
            return []
            
    def load_requests(self) -> List[Dict]:
        """Load requests from JSON file"""
        try:
            if os.path.exists(self.requests_file):
                with open(self.requests_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                os.makedirs(os.path.dirname(self.requests_file), exist_ok=True)
                return []
        except Exception as e:
            self.logger.error(f"Error loading requests: {e}")
            return []
            
    def save_customers(self) -> bool:
        """Save customers to JSON file"""
        try:
            with open(self.customers_file, 'w', encoding='utf-8') as f:
                json.dump(self.customers, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            self.logger.error(f"Error saving customers: {e}")
            return False
            
    def save_requests(self) -> bool:
        """Save requests to JSON file"""
        try:
            with open(self.requests_file, 'w', encoding='utf-8') as f:
                json.dump(self.requests, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            self.logger.error(f"Error saving requests: {e}")
            return False
            
    def register_customer(self, user_id: int, first_name: str, last_name: str, username: str, phone_number: str) -> bool:
        """Register a new customer"""
        try:
            # Check if customer already exists
            if self.is_registered(user_id):
                return False
                
            customer = {
                'user_id': user_id,
                'first_name': first_name,
                'last_name': last_name,
                'username': username,
                'phone_number': phone_number,
                'registration_date': datetime.now().isoformat(),
                'status': 'active'
            }
            
            self.customers.append(customer)
            return self.save_customers()
            
        except Exception as e:
            self.logger.error(f"Error registering customer: {e}")
            return False
            
    def is_registered(self, user_id: int) -> bool:
        """Check if user is registered"""
        return any(customer['user_id'] == user_id for customer in self.customers)
        
    def get_customer_by_id(self, user_id: int) -> Optional[Dict]:
        """Get customer by user ID"""
        for customer in self.customers:
            if customer['user_id'] == user_id:
                return customer
        return None
        
    def log_user_request(self, user_id: int, user_name: str, message: str) -> bool:
        """Log user request"""
        try:
            # Get customer phone if registered
            customer = self.get_customer_by_id(user_id)
            phone = customer['phone_number'] if customer else ""
            
            request = {
                'user_id': user_id,
                'user_name': user_name,
                'phone': phone,
                'message': message,
                'timestamp': datetime.now().isoformat(),
                'status': 'pending'
            }
            
            self.requests.append(request)
            return self.save_requests()
            
        except Exception as e:
            self.logger.error(f"Error logging user request: {e}")
            return False
            
    def get_all_customers(self) -> List[Dict]:
        """Get all customers"""
        return self.customers
        
    def get_all_requests(self) -> List[Dict]:
        """Get all requests"""
        return self.requests
        
    def get_user_recent_requests(self, user_id: int, limit: int = 10) -> List[Dict]:
        """Get recent requests for a specific user"""
        user_requests = [req for req in self.requests if req['user_id'] == user_id]
        user_requests.sort(key=lambda x: x['timestamp'], reverse=True)
        return user_requests[:limit]
        
    def get_recent_requests(self, limit: int = 50) -> List[Dict]:
        """Get recent requests from all users"""
        requests = sorted(self.requests, key=lambda x: x['timestamp'], reverse=True)
        return requests[:limit]
        
    def get_customer_stats(self) -> Dict:
        """Get customer statistics"""
        if not self.customers:
            return {
                'total_customers': 0,
                'active_customers': 0,
                'recent_registrations': 0
            }
            
        # Count active customers
        active_customers = sum(1 for customer in self.customers if customer.get('status') == 'active')
        
        # Count recent registrations (last 30 days)
        from datetime import datetime, timedelta
        thirty_days_ago = datetime.now() - timedelta(days=30)
        recent_registrations = 0
        
        for customer in self.customers:
            try:
                reg_date = datetime.fromisoformat(customer.get('registration_date', ''))
                if reg_date > thirty_days_ago:
                    recent_registrations += 1
            except:
                pass
                
        return {
            'total_customers': len(self.customers),
            'active_customers': active_customers,
            'recent_registrations': recent_registrations
        }
        
    def get_request_stats(self) -> Dict:
        """Get request statistics"""
        if not self.requests:
            return {
                'total_requests': 0,
                'pending_requests': 0,
                'recent_requests': 0
            }
            
        # Count pending requests
        pending_requests = sum(1 for req in self.requests if req.get('status') == 'pending')
        
        # Count recent requests (last 7 days)
        from datetime import datetime, timedelta
        seven_days_ago = datetime.now() - timedelta(days=7)
        recent_requests = 0
        
        for request in self.requests:
            try:
                req_date = datetime.fromisoformat(request.get('timestamp', ''))
                if req_date > seven_days_ago:
                    recent_requests += 1
            except:
                pass
                
        return {
            'total_requests': len(self.requests),
            'pending_requests': pending_requests,
            'recent_requests': recent_requests
        }
        
    def update_customer_status(self, user_id: int, status: str) -> bool:
        """Update customer status"""
        try:
            for customer in self.customers:
                if customer['user_id'] == user_id:
                    customer['status'] = status
                    customer['updated_at'] = datetime.now().isoformat()
                    return self.save_customers()
            return False
        except Exception as e:
            self.logger.error(f"Error updating customer status: {e}")
            return False
            
    def mark_request_as_processed(self, request_id: int) -> bool:
        """Mark request as processed"""
        try:
            if 0 <= request_id < len(self.requests):
                self.requests[request_id]['status'] = 'processed'
                self.requests[request_id]['processed_at'] = datetime.now().isoformat()
                return self.save_requests()
            return False
        except Exception as e:
            self.logger.error(f"Error marking request as processed: {e}")
            return False
            
    def search_customers(self, query: str) -> List[Dict]:
        """Search customers by name or phone"""
        if not query:
            return []
            
        query = query.lower()
        results = []
        
        for customer in self.customers:
            searchable_text = f"{customer.get('first_name', '')} {customer.get('last_name', '')} {customer.get('phone_number', '')} {customer.get('username', '')}".lower()
            
            if query in searchable_text:
                results.append(customer)
                
        return results
        
    def get_customer_activity(self, user_id: int) -> Dict:
        """Get customer activity summary"""
        customer = self.get_customer_by_id(user_id)
        if not customer:
            return {}
            
        user_requests = [req for req in self.requests if req['user_id'] == user_id]
        
        return {
            'customer_info': customer,
            'total_requests': len(user_requests),
            'recent_requests': sorted(user_requests, key=lambda x: x['timestamp'], reverse=True)[:10]
        }
