#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Configuration for Telegram Real Estate Bot
"""

import os
from typing import Dict, List

class Config:
    # Bot Configuration
    BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    
    # Admin Configuration
    ADMIN_USER_IDS = [int(id) for id in os.getenv("ADMIN_USER_IDS", "").split(",") if id.strip()]
    
    # Company Information
    COMPANY_NAME = "شرکت املاک ایوان"
    COMPANY_PHONE = "021-12345678"
    COMPANY_ADDRESS = "تهران، خیابان ولیعصر، پلاک 123"
    COMPANY_WEBSITE = "https://eivan-realestate.com"
    
    # Bot Settings
    MAX_SEARCH_RESULTS = 10
    MAX_MESSAGE_LENGTH = 1000
    
    # File Paths
    DATA_DIR = "data"
    LOGS_DIR = "logs"
    
    # Database Files
    PROPERTIES_FILE = os.path.join(DATA_DIR, "properties.json")
    CUSTOMERS_FILE = os.path.join(DATA_DIR, "customers.json")
    REQUESTS_FILE = os.path.join(DATA_DIR, "requests.json")
    TEXTS_FILE = os.path.join(DATA_DIR, "texts.json")
    ADMINS_FILE = os.path.join(DATA_DIR, "admins.json")
    
    # Logging Configuration
    LOG_LEVEL = "INFO"
    LOG_FILE = "bot.log"
    
    # GPT Configuration
    GPT_MODEL = "gpt-4o"  # the newest OpenAI model is "gpt-4o" which was released May 13, 2024
    GPT_TEMPERATURE = 0.7
    GPT_MAX_TOKENS = 1000
    
    # Webhook Configuration (optional)
    WEBHOOK_URL = os.getenv("WEBHOOK_URL", "")
    WEBHOOK_PORT = int(os.getenv("WEBHOOK_PORT", "8443"))
    
    # Security Configuration
    RATE_LIMIT_ENABLED = True
    RATE_LIMIT_REQUESTS = 30  # requests per minute
    
    # File Upload Configuration
    MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB
    ALLOWED_FILE_TYPES = ['.json', '.csv', '.txt']
    
    # Property Configuration
    PROPERTY_TYPES = [
        'آپارتمان', 'خانه', 'ویلا', 'تجاری', 'اداری', 
        'صنعتی', 'زمین', 'باغ', 'مغازه', 'دفتر کار'
    ]
    
    # Search Configuration
    SEARCH_SIMILARITY_THRESHOLD = 0.7
    SEARCH_TIMEOUT = 30  # seconds
    
    # Customer Configuration
    REGISTRATION_REQUIRED_FIELDS = ['first_name', 'phone_number']
    
    # Keyboard Configuration
    KEYBOARD_RESIZE = True
    KEYBOARD_ONE_TIME = False
    
    @classmethod
    def get_admin_ids(cls) -> List[int]:
        """Get list of admin user IDs"""
        return cls.ADMIN_USER_IDS
    
    @classmethod
    def is_admin(cls, user_id: int) -> bool:
        """Check if user is admin"""
        return user_id in cls.ADMIN_USER_IDS
        
    @classmethod
    def get_company_info(cls) -> Dict[str, str]:
        """Get company information"""
        return {
            'name': cls.COMPANY_NAME,
            'phone': cls.COMPANY_PHONE,
            'address': cls.COMPANY_ADDRESS,
            'website': cls.COMPANY_WEBSITE
        }
        
    @classmethod
    def get_file_paths(cls) -> Dict[str, str]:
        """Get all file paths"""
        return {
            'properties': cls.PROPERTIES_FILE,
            'customers': cls.CUSTOMERS_FILE,
            'requests': cls.REQUESTS_FILE,
            'texts': cls.TEXTS_FILE,
            'admins': cls.ADMINS_FILE
        }
        
    @classmethod
    def setup_directories(cls):
        """Create necessary directories"""
        import os
        
        directories = [cls.DATA_DIR, cls.LOGS_DIR]
        for directory in directories:
            os.makedirs(directory, exist_ok=True)
            
    @classmethod
    def validate_config(cls) -> List[str]:
        """Validate configuration and return list of errors"""
        errors = []
        
        if not cls.BOT_TOKEN:
            errors.append("TELEGRAM_BOT_TOKEN is required")
            
        if not cls.OPENAI_API_KEY:
            errors.append("OPENAI_API_KEY is required")
            
        if not cls.ADMIN_USER_IDS:
            errors.append("At least one admin user ID is required")
            
        return errors
