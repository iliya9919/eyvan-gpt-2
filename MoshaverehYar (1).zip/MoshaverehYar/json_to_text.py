#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
JSON to Text Converter for Telegram Real Estate Bot
Converts JSON data to beautiful Persian text using GPT
"""

import json
import logging
from typing import Dict, List, Any
from openai import OpenAI
import os
from config import Config

class JsonToText:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY", "default_key"))
        
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        self.model = "gpt-4o"
        
    async def property_to_text(self, property_data: Dict) -> str:
        """Convert single property JSON to beautiful Persian text"""
        try:
            prompt = """
شما یک تبدیل‌کننده اطلاعات املاک هستید. اطلاعات ملک به صورت JSON داده می‌شود و باید آن را به متن زیبا و قابل فهم فارسی تبدیل کنید.

فرمت خروجی:
🏠 [نوع ملک] - کد [کد ملک]
📍 آدرس: [آدرس]
💰 قیمت: [قیمت فرمت شده]
📐 متراژ: [متراژ] متر مربع
🛏️ تعداد اتاق: [تعداد اتاق خواب]
🏗️ سال ساخت: [سال ساخت]
🏢 طبقه: [طبقه]

📝 توضیحات:
[توضیحات کامل و جذاب]

استفاده کنید از:
- ایموجی مناسب
- فرمت قیمت زیبا (میلیون، میلیارد)
- متن جذاب و فروشنده
- فارسی صحیح
"""
            
            property_json = json.dumps(property_data, ensure_ascii=False, indent=2)
            
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": f"اطلاعات ملک:\n{property_json}"}
                ],
                temperature=0.5,
                max_tokens=800
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"Error converting property to text: {e}")
            return self._fallback_property_text(property_data)
            
    async def properties_to_text(self, properties: List[Dict]) -> str:
        """Convert multiple properties to beautiful text"""
        try:
            if not properties:
                return "❌ هیچ ملکی یافت نشد."
                
            prompt = """
شما لیست املاک را به متن زیبا و منظم تبدیل می‌کنید.

فرمت خروجی برای هر ملک:
🏠 [نوع] - [کد] | 💰 [قیمت] | 📐 [متراژ]m² | 🛏️ [اتاق]
📍 [آدرس کوتاه]
[توضیحات خلاصه]
───────────────────

در پایان:
📊 تعداد املاک یافت شده: [تعداد]

استفاده کنید از:
- ایموجی مناسب
- فرمت کوتاه و خلاصه
- قیمت فرمت شده
- فارسی صحیح
"""
            
            properties_json = json.dumps(properties, ensure_ascii=False, indent=2)
            
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": f"لیست املاک:\n{properties_json}"}
                ],
                temperature=0.5,
                max_tokens=1500
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"Error converting properties to text: {e}")
            return self._fallback_properties_text(properties)
            
    async def customers_to_text(self, customers: List[Dict]) -> str:
        """Convert customers list to beautiful text"""
        try:
            if not customers:
                return "📋 هیچ مشتری ثبت نام نکرده است."
                
            prompt = """
شما لیست مشتریان را به متن زیبا و منظم تبدیل می‌کنید.

فرمت خروجی:
👥 لیست مشتریان

برای هر مشتری:
👤 [نام] [نام خانوادگی]
📱 [شماره تلفن]
🆔 [username اگر دارد]
📅 ثبت نام: [تاریخ]
🟢 وضعیت: [وضعیت]
───────────────────

در پایان:
📊 تعداد کل مشتریان: [تعداد]

استفاده کنید از:
- ایموجی مناسب
- فرمت تاریخ فارسی
- متن منظم
- حفظ حریم خصوصی
"""
            
            customers_json = json.dumps(customers, ensure_ascii=False, indent=2)
            
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": f"لیست مشتریان:\n{customers_json}"}
                ],
                temperature=0.5,
                max_tokens=1500
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"Error converting customers to text: {e}")
            return self._fallback_customers_text(customers)
            
    async def stats_to_text(self, stats: Dict) -> str:
        """Convert statistics to beautiful text"""
        try:
            prompt = """
شما آمار سیستم را به متن زیبا و قابل فهم تبدیل می‌کنید.

فرمت خروجی:
📊 آمار سیستم

🏠 املاک:
• تعداد کل: [تعداد]
• میانگین قیمت: [قیمت]
• میانگین متراژ: [متراژ]
• کمترین قیمت: [قیمت]
• بیشترین قیمت: [قیمت]

👥 مشتریان:
• تعداد کل: [تعداد]
• فعال: [تعداد]
• ثبت نام‌های اخیر: [تعداد]

📨 درخواست‌ها:
• تعداد کل: [تعداد]
• در انتظار: [تعداد]
• اخیر: [تعداد]

استفاده کنید از:
- ایموجی مناسب
- فرمت قیمت زیبا
- اعداد فارسی
- متن منظم
"""
            
            stats_json = json.dumps(stats, ensure_ascii=False, indent=2)
            
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": f"آمار سیستم:\n{stats_json}"}
                ],
                temperature=0.5,
                max_tokens=1000
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"Error converting stats to text: {e}")
            return self._fallback_stats_text(stats)
            
    async def admins_to_text(self, admins: List[Dict]) -> str:
        """Convert admins list to beautiful text"""
        try:
            if not admins:
                return "👑 هیچ ادمینی ثبت نشده است."
                
            prompt = """
شما لیست ادمین‌ها را به متن زیبا تبدیل می‌کنید.

فرمت خروجی:
👑 لیست ادمین‌ها

برای هر ادمین:
👤 [نام]
🆔 ID: [user_id]
📅 اضافه شده: [تاریخ]
👨‍💼 اضافه کننده: [added_by]
🟢 وضعیت: [وضعیت]
───────────────────

در پایان:
📊 تعداد کل ادمین‌ها: [تعداد]

استفاده کنید از:
- ایموجی مناسب
- فرمت تاریخ فارسی
- متن منظم
- حفظ امنیت
"""
            
            admins_json = json.dumps(admins, ensure_ascii=False, indent=2)
            
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": f"لیست ادمین‌ها:\n{admins_json}"}
                ],
                temperature=0.5,
                max_tokens=1000
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"Error converting admins to text: {e}")
            return self._fallback_admins_text(admins)
            
    async def upload_result_to_text(self, result: Dict) -> str:
        """Convert file upload result to beautiful text"""
        try:
            prompt = """
شما نتیجه آپلود فایل را به متن زیبا تبدیل می‌کنید.

فرمت خروجی:
📤 نتیجه آپلود فایل

✅ موفقیت‌آمیز: [تعداد]
❌ خطا: [تعداد]
⏭️ رد شده: [تعداد]

🔍 جزئیات:
[لیست خطاها اگر وجود دارد]

📊 خلاصه:
[خلاصه کلی نتیجه]

استفاده کنید از:
- ایموجی مناسب
- پیام‌های واضح
- فارسی صحیح
- متن مفید
"""
            
            result_json = json.dumps(result, ensure_ascii=False, indent=2)
            
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": f"نتیجه آپلود:\n{result_json}"}
                ],
                temperature=0.5,
                max_tokens=800
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"Error converting upload result to text: {e}")
            return self._fallback_upload_result_text(result)
            
    async def report_to_text(self, report_data: Dict) -> str:
        """Convert report data to beautiful text"""
        try:
            prompt = """
شما گزارش کامل سیستم را به متن زیبا تبدیل می‌کنید.

فرمت خروجی:
📋 گزارش سیستم
📅 تاریخ: [تاریخ]

📊 آمار کلی:
[آمار املاک، مشتریان، درخواست‌ها]

🔥 فعالیت‌های اخیر:
[فعالیت‌های اخیر]

📈 تحلیل:
[تحلیل کلی وضعیت]

استفاده کنید از:
- ایموجی مناسب
- فرمت تاریخ فارسی
- آمار واضح
- تحلیل مفید
"""
            
            report_json = json.dumps(report_data, ensure_ascii=False, indent=2)
            
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": f"گزارش سیستم:\n{report_json}"}
                ],
                temperature=0.5,
                max_tokens=1500
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"Error converting report to text: {e}")
            return self._fallback_report_text(report_data)
            
    # Fallback methods (when GPT fails)
    def _fallback_property_text(self, property_data: Dict) -> str:
        """Fallback property text formatting"""
        code = property_data.get('code', 'N/A')
        prop_type = property_data.get('type', 'نامشخص')
        address = property_data.get('address', 'آدرس نامشخص')
        price = property_data.get('price', 0)
        area = property_data.get('area', 0)
        bedrooms = property_data.get('bedrooms', 0)
        description = property_data.get('description', 'توضیحات موجود نیست')
        
        price_formatted = f"{price:,} تومان" if price else "قیمت نامشخص"
        
        return f"""
🏠 {prop_type} - کد {code}
📍 آدرس: {address}
💰 قیمت: {price_formatted}
📐 متراژ: {area} متر مربع
🛏️ تعداد اتاق: {bedrooms}

📝 توضیحات:
{description}
        """
        
    def _fallback_properties_text(self, properties: List[Dict]) -> str:
        """Fallback properties list formatting"""
        if not properties:
            return "❌ هیچ ملکی یافت نشد."
            
        text = "🏠 لیست املاک:\n\n"
        
        for prop in properties[:10]:  # Limit to 10 properties
            code = prop.get('code', 'N/A')
            prop_type = prop.get('type', 'نامشخص')
            price = prop.get('price', 0)
            area = prop.get('area', 0)
            bedrooms = prop.get('bedrooms', 0)
            
            price_formatted = f"{price:,}" if price else "نامشخص"
            
            text += f"• {prop_type} - {code}\n"
            text += f"  💰 {price_formatted} | 📐 {area}m² | 🛏️ {bedrooms}\n\n"
            
        text += f"📊 تعداد کل: {len(properties)}"
        return text
        
    def _fallback_customers_text(self, customers: List[Dict]) -> str:
        """Fallback customers list formatting"""
        if not customers:
            return "📋 هیچ مشتری ثبت نام نکرده است."
            
        text = "👥 لیست مشتریان:\n\n"
        
        for customer in customers[:20]:  # Limit to 20 customers
            name = f"{customer.get('first_name', '')} {customer.get('last_name', '')}".strip()
            phone = customer.get('phone_number', 'نامشخص')
            username = customer.get('username', '')
            
            text += f"👤 {name}\n"
            text += f"📱 {phone}\n"
            if username:
                text += f"🆔 @{username}\n"
            text += "\n"
            
        text += f"📊 تعداد کل: {len(customers)}"
        return text
        
    def _fallback_stats_text(self, stats: Dict) -> str:
        """Fallback stats formatting"""
        properties = stats.get('properties', {})
        customers = stats.get('customers', {})
        requests = stats.get('requests', {})
        
        return f"""
📊 آمار سیستم

🏠 املاک:
• تعداد کل: {properties.get('total_properties', 0)}
• میانگین قیمت: {properties.get('average_price', 0):,.0f} تومان
• میانگین متراژ: {properties.get('average_area', 0):.0f} متر مربع

👥 مشتریان:
• تعداد کل: {customers.get('total_customers', 0)}
• فعال: {customers.get('active_customers', 0)}
• ثبت نام‌های اخیر: {customers.get('recent_registrations', 0)}

📨 درخواست‌ها:
• تعداد کل: {requests.get('total_requests', 0)}
• در انتظار: {requests.get('pending_requests', 0)}
• اخیر: {requests.get('recent_requests', 0)}
        """
        
    def _fallback_admins_text(self, admins: List[Dict]) -> str:
        """Fallback admins list formatting"""
        if not admins:
            return "👑 هیچ ادمینی ثبت نشده است."
            
        text = "👑 لیست ادمین‌ها:\n\n"
        
        for admin in admins:
            name = admin.get('name', 'نامشخص')
            user_id = admin.get('user_id', 'نامشخص')
            
            text += f"👤 {name}\n"
            text += f"🆔 ID: {user_id}\n\n"
            
        text += f"📊 تعداد کل: {len(admins)}"
        return text
        
    def _fallback_upload_result_text(self, result: Dict) -> str:
        """Fallback upload result formatting"""
        return f"""
📤 نتیجه آپلود فایل

✅ موفقیت‌آمیز: {result.get('added', 0)}
❌ خطا: {result.get('skipped', 0)}

📊 خلاصه: {result.get('added', 0)} ملک با موفقیت اضافه شد.
        """
        
    def _fallback_report_text(self, report_data: Dict) -> str:
        """Fallback report formatting"""
        return f"""
📋 گزارش سیستم
📅 تاریخ: {report_data.get('timestamp', 'نامشخص')}

📊 آمار کلی دردسترس است.
        """
