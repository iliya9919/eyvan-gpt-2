#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GPT Integration for Telegram Real Estate Bot
Handles AI-powered message processing using OpenAI GPT-4
"""

import os
import json
import logging
from typing import Dict, List, Optional
from openai import OpenAI
from config import Config
from property_manager import PropertyManager
from customer_manager import CustomerManager
from text_manager import TextManager

class GPTIntegration:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY", "default_key"))
        self.property_manager = PropertyManager()
        self.customer_manager = CustomerManager()
        self.text_manager = TextManager()
        
        # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
        # do not change this unless explicitly requested by the user
        self.model = "gpt-4o"
        
    async def process_message(self, message: str, user_id: int) -> str:
        """Process user message with GPT"""
        try:
            # Get user context
            user_context = self._get_user_context(user_id)
            
            # Get system prompt
            system_prompt = self.text_manager.get_text("gpt_system_prompt")
            
            # Prepare context for GPT
            context_message = self._prepare_context(message, user_context)
            
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": context_message}
                ],
                temperature=0.7,
                max_tokens=1000
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"Error processing message with GPT: {e}")
            return self.text_manager.get_text("gpt_error")
            
    def _get_user_context(self, user_id: int) -> Dict:
        """Get user context for GPT"""
        customer = self.customer_manager.get_customer_by_id(user_id)
        recent_requests = self.customer_manager.get_user_recent_requests(user_id, 5)
        
        return {
            'is_registered': customer is not None,
            'customer_info': customer,
            'recent_requests': recent_requests,
            'available_properties': len(self.property_manager.get_all_properties())
        }
        
    def _prepare_context(self, message: str, user_context: Dict) -> str:
        """Prepare context message for GPT"""
        context_parts = [
            f"پیام کاربر: {message}",
            f"وضعیت ثبت نام: {'ثبت نام شده' if user_context['is_registered'] else 'ثبت نام نشده'}",
            f"تعداد املاک موجود: {user_context['available_properties']}",
        ]
        
        if user_context['recent_requests']:
            context_parts.append("درخواست‌های اخیر:")
            for req in user_context['recent_requests']:
                context_parts.append(f"- {req['message']}")
                
        return "\n".join(context_parts)
        
    async def search_properties_with_gpt(self, query: str) -> List[Dict]:
        """Search properties using GPT interpretation"""
        try:
            search_prompt = self.text_manager.get_text("gpt_search_prompt")
            
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": search_prompt},
                    {"role": "user", "content": f"جستجو برای: {query}"}
                ],
                response_format={"type": "json_object"},
                temperature=0.3
            )
            
            search_params = json.loads(response.choices[0].message.content)
            
            # Use search parameters to find properties
            all_properties = self.property_manager.get_all_properties()
            filtered_properties = self._filter_properties(all_properties, search_params)
            
            return filtered_properties
            
        except Exception as e:
            self.logger.error(f"Error in GPT property search: {e}")
            return self.property_manager.search_properties(query)
            
    def _filter_properties(self, properties: List[Dict], search_params: Dict) -> List[Dict]:
        """Filter properties based on GPT search parameters"""
        filtered = properties
        
        # Filter by type
        if 'type' in search_params and search_params['type']:
            filtered = [p for p in filtered if p.get('type') == search_params['type']]
            
        # Filter by price range
        if 'min_price' in search_params and search_params['min_price']:
            filtered = [p for p in filtered if p.get('price', 0) >= search_params['min_price']]
            
        if 'max_price' in search_params and search_params['max_price']:
            filtered = [p for p in filtered if p.get('price', 0) <= search_params['max_price']]
            
        # Filter by area range
        if 'min_area' in search_params and search_params['min_area']:
            filtered = [p for p in filtered if p.get('area', 0) >= search_params['min_area']]
            
        if 'max_area' in search_params and search_params['max_area']:
            filtered = [p for p in filtered if p.get('area', 0) <= search_params['max_area']]
            
        # Filter by bedrooms
        if 'bedrooms' in search_params and search_params['bedrooms']:
            filtered = [p for p in filtered if p.get('bedrooms', 0) == search_params['bedrooms']]
            
        # Filter by location keywords
        if 'location_keywords' in search_params and search_params['location_keywords']:
            for keyword in search_params['location_keywords']:
                filtered = [p for p in filtered if keyword.lower() in p.get('address', '').lower()]
                
        return filtered
        
    async def generate_property_description(self, property_data: Dict) -> str:
        """Generate enhanced property description using GPT"""
        try:
            description_prompt = self.text_manager.get_text("gpt_description_prompt")
            
            property_json = json.dumps(property_data, ensure_ascii=False, indent=2)
            
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": description_prompt},
                    {"role": "user", "content": f"اطلاعات ملک:\n{property_json}"}
                ],
                temperature=0.5,
                max_tokens=500
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"Error generating property description: {e}")
            return property_data.get('description', 'توضیحات در دسترس نیست')
            
    async def format_price(self, price: int) -> str:
        """Format price using GPT"""
        try:
            price_prompt = self.text_manager.get_text("gpt_price_format_prompt")
            
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": price_prompt},
                    {"role": "user", "content": f"قیمت: {price}"}
                ],
                temperature=0.1,
                max_tokens=100
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            self.logger.error(f"Error formatting price: {e}")
            return f"{price:,} تومان"
            
    async def analyze_user_intent(self, message: str) -> Dict:
        """Analyze user intent using GPT"""
        try:
            intent_prompt = self.text_manager.get_text("gpt_intent_prompt")
            
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": intent_prompt},
                    {"role": "user", "content": message}
                ],
                response_format={"type": "json_object"},
                temperature=0.3
            )
            
            return json.loads(response.choices[0].message.content)
            
        except Exception as e:
            self.logger.error(f"Error analyzing user intent: {e}")
            return {"intent": "general", "confidence": 0.5}
