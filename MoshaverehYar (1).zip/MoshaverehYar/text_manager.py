#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Text Manager for Telegram Real Estate Bot
Manages customizable texts and messages
"""

import json
import os
import logging
from typing import Dict, Optional
from config import Config

class TextManager:
    def __init__(self, texts_file: str = None):
        self.texts_file = texts_file or Config.TEXTS_FILE
        self.logger = logging.getLogger(__name__)
        self.texts = self.load_texts()
        
    def load_texts(self) -> Dict[str, str]:
        """Load texts from JSON file"""
        try:
            if os.path.exists(self.texts_file):
                with open(self.texts_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                # Create directory if it doesn't exist
                os.makedirs(os.path.dirname(self.texts_file), exist_ok=True)
                # Return default texts
                return self.get_default_texts()
        except Exception as e:
            self.logger.error(f"Error loading texts: {e}")
            return self.get_default_texts()
            
    def save_texts(self) -> bool:
        """Save texts to JSON file"""
        try:
            with open(self.texts_file, 'w', encoding='utf-8') as f:
                json.dump(self.texts, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            self.logger.error(f"Error saving texts: {e}")
            return False
            
    def get_text(self, key: str, default: str = "") -> str:
        """Get text by key"""
        return self.texts.get(key, default)
        
    def update_text(self, key: str, value: str) -> bool:
        """Update text value"""
        try:
            self.texts[key] = value
            return self.save_texts()
        except Exception as e:
            self.logger.error(f"Error updating text: {e}")
            return False
            
    def reset_text(self, key: str) -> bool:
        """Reset text to default value"""
        try:
            defaults = self.get_default_texts()
            if key in defaults:
                self.texts[key] = defaults[key]
                return self.save_texts()
            return False
        except Exception as e:
            self.logger.error(f"Error resetting text: {e}")
            return False
            
    def get_all_texts(self) -> Dict[str, str]:
        """Get all texts"""
        return self.texts.copy()
        
    def get_default_texts(self) -> Dict[str, str]:
        """Get default texts"""
        return {
            # Welcome and basic messages
            "welcome_message": f"""
🏠 <b>به {Config.COMPANY_NAME} خوش آمدید!</b>

ما بزرگترین مرجع املاک در شهر هستیم و آماده ارائه بهترین خدمات به شما عزیزان می‌باشیم.

🔍 <b>خدمات ما:</b>
• جستجوی املاک
• مشاوره تخصصی
• خرید و فروش
• رهن و اجاره

📞 <b>تماس:</b> {Config.COMPANY_PHONE}
🌐 <b>وبسایت:</b> {Config.COMPANY_WEBSITE}

برای شروع، یکی از گزینه‌های زیر را انتخاب کنید:
            """,
            
            "user_help": """
❓ <b>راهنمای استفاده</b>

🏠 <b>جستجوی املاک:</b>
• /search [متن جستجو] - جستجو در املاک
• ارسال کد ملک (مثل EV001) - مشاهده جزئیات

📋 <b>ثبت نام:</b>
• /register - ثبت نام در سیستم
• اشتراک شماره تلفن

📞 <b>تماس با مشاور:</b>
• دریافت اطلاعات تماس
• درخواست مشاوره

💬 <b>پیام دادن:</b>
• سوال کردن از هوش مصنوعی
• درخواست اطلاعات

برای هر گونه سوال، کافیست پیام خود را بنویسید.
            """,
            
            "admin_help": """
🔧 <b>راهنمای مدیریت</b>

👥 <b>مدیریت مشتریان:</b>
• /customers - لیست مشتریان
• /stats - آمار کلی سیستم

🏠 <b>مدیریت املاک:</b>
• /list_properties - لیست املاک
• /add_property - افزودن ملک
• /edit_property - ویرایش ملک
• /delete_property - حذف ملک
• /uploadproperties - آپلود فایل املاک

📝 <b>مدیریت متن‌ها:</b>
• /edittexts [کلید] [متن] - ویرایش متن
• /resettext [کلید] - بازگشت به پیش‌فرض

👤 <b>مدیریت ادمین‌ها:</b>
• /addadmin [ID] [نام] - افزودن ادمین
• /removeadmin [ID] - حذف ادمین
• /listadmins - لیست ادمین‌ها

📊 <b>گزارش‌ها:</b>
• /report - گزارش کامل
• /export_data - خروجی داده‌ها
• /backup - پشتیبان‌گیری

⚙️ <b>تنظیمات:</b>
• /settings - تنظیمات سیستم
• /edit_prompts - ویرایش پرامپت‌های GPT
• /edit_welcome - ویرایش پیام خوشامد
• /edit_company - ویرایش اطلاعات شرکت
            """,
            
            # Search related
            "search_help": """
🔍 <b>راهنمای جستجو</b>

<b>روش‌های جستجو:</b>
• /search آپارتمان - جستجو بر اساس نوع
• /search تهران - جستجو بر اساس منطقه
• /search 2 خواب - جستجو بر اساس تعداد اتاق
• /search زیر 500 میلیون - جستجو بر اساس قیمت
• /search بالای 100 متر - جستجو بر اساس متراژ

<b>ارسال کد ملک:</b>
• EV001 - مشاهده جزئیات ملک

<b>مثال‌های جستجو:</b>
• "آپارتمان 2 خواب تهران"
• "ویلا زیر 2 میلیارد"
• "مغازه خیابان ولیعصر"
            """,
            
            "no_results_found": "❌ موردی یافت نشد. لطفاً عبارت جستجو را تغییر دهید.",
            
            "property_not_found": "❌ ملک با این کد پیدا نشد. لطفاً کد را بررسی کنید.",
            
            # Registration
            "request_contact": "📱 برای ثبت نام، لطفاً شماره تلفن خود را از طریق دکمه زیر اشتراک بگذارید:",
            
            "already_registered": "✅ شما قبلاً ثبت نام کرده‌اید.",
            
            "registration_success": "✅ ثبت نام شما با موفقیت انجام شد! حالا می‌توانید از تمام خدمات استفاده کنید.",
            
            "registration_failed": "❌ خطا در ثبت نام. لطفاً دوباره تلاش کنید.",
            
            "invalid_contact": "❌ لطفاً شماره تلفن خود را ارسال کنید.",
            
            # Contact info
            "contact_info": f"""
📞 <b>اطلاعات تماس</b>

🏢 <b>شرکت:</b> {Config.COMPANY_NAME}
📱 <b>تلفن:</b> {Config.COMPANY_PHONE}
📍 <b>آدرس:</b> {Config.COMPANY_ADDRESS}
🌐 <b>وبسایت:</b> {Config.COMPANY_WEBSITE}

⏰ <b>ساعات کاری:</b>
شنبه تا پنجشنبه: 9 صبح تا 6 عصر
جمعه: تعطیل

برای مشاوره رایگان با ما تماس بگیرید!
            """,
            
            # Error messages
            "error_processing_message": "❌ خطا در پردازش پیام. لطفاً دوباره تلاش کنید.",
            
            "invalid_message": "❌ پیام نامعتبر است. لطفاً پیام صحیح ارسال کنید.",
            
            "access_denied": "❌ شما اجازه دسترسی به این بخش را ندارید.",
            
            "file_upload_error": "❌ خطا در آپلود فایل. لطفاً فایل صحیح ارسال کنید.",
            
            "gpt_error": "❌ خطا در پردازش با هوش مصنوعی. لطفاً دوباره تلاش کنید.",
            
            # Admin messages
            "no_customers": "📋 هیچ مشتری ثبت نام نکرده است.",
            
            "no_properties": "🏠 هیچ ملکی ثبت نشده است.",
            
            "add_admin_help": "📝 استفاده: /addadmin [ID کاربر] [نام]\n\nمثال: /addadmin 123456789 علی احمدی",
            
            "remove_admin_help": "📝 استفاده: /removeadmin [ID کاربر]\n\nمثال: /removeadmin 123456789",
            
            "admin_added_success": "✅ ادمین جدید با موفقیت اضافه شد:\nID: {admin_id}\nنام: {name}",
            
            "admin_already_exists": "❌ این کاربر قبلاً ادمین است.",
            
            "admin_removed_success": "✅ ادمین با ID {admin_id} حذف شد.",
            
            "admin_remove_failed": "❌ خطا در حذف ادمین. ممکن است وجود نداشته باشد.",
            
            "invalid_user_id": "❌ ID کاربر نامعتبر است.",
            
            "edit_texts_help": """
📝 <b>ویرایش متن‌ها</b>

<b>استفاده:</b> /edittexts [کلید] [متن جدید]

<b>کلیدهای قابل ویرایش:</b>
• welcome_message - پیام خوشامد
• user_help - راهنمای کاربر
• admin_help - راهنمای ادمین
• search_help - راهنمای جستجو
• contact_info - اطلاعات تماس
• no_results_found - پیام عدم یافتن نتیجه
• property_not_found - پیام عدم یافتن ملک

<b>مثال:</b>
/edittexts welcome_message سلام! به سایت املاک ما خوش آمدید
            """,
            
            "reset_text_help": """
🔄 <b>بازنشانی متن</b>

<b>استفاده:</b> /resettext [کلید]

<b>مثال:</b>
/resettext welcome_message
            """,
            
            "text_updated_success": "✅ متن '{key}' با موفقیت بروزرسانی شد.",
            
            "text_update_failed": "❌ خطا در بروزرسانی متن.",
            
            "text_reset_success": "✅ متن '{key}' به حالت پیش‌فرض بازگشت.",
            
            "text_reset_failed": "❌ خطا در بازنشانی متن.",
            
            "upload_properties_help": """
📤 <b>آپلود فایل املاک</b>

<b>فرمت‌های پشتیبانی شده:</b>
• JSON - فایل JSON با لیست املاک
• CSV - فایل CSV با ستون‌های مشخص

<b>ستون‌های مورد نیاز CSV:</b>
• code - کد ملک (مثل EV001)
• type - نوع ملک
• address - آدرس
• price - قیمت (عدد)
• area - متراژ (عدد)
• bedrooms - تعداد اتاق خواب
• description - توضیحات

<b>برای آپلود:</b>
فایل را در همین چت ارسال کنید.
            """,
            
            "add_property_help": """
🏠 <b>افزودن ملک جدید</b>

<b>فرمت JSON:</b>
{
    "code": "EV001",
    "type": "آپارتمان",
    "address": "تهران، خیابان ولیعصر",
    "price": 800000000,
    "area": 85,
    "bedrooms": 2,
    "description": "آپارتمان دو خواب با نور عالی"
}
            """,
            
            "edit_property_help": "🔧 برای ویرایش ملک، کد ملک و اطلاعات جدید را ارسال کنید.",
            
            "delete_property_help": "🗑️ برای حذف ملک، کد ملک را ارسال کنید.",
            
            "edit_welcome_help": "📝 برای ویرایش پیام خوشامد از /edittexts welcome_message استفاده کنید.",
            
            "edit_company_help": "🏢 برای ویرایش اطلاعات شرکت از /edittexts contact_info استفاده کنید.",
            
            "edit_prompts_help": "🤖 برای ویرایش پرامپت‌های GPT از کلیدهای gpt_* استفاده کنید.",
            
            "export_data_help": "📊 خروجی داده‌ها در حال آماده‌سازی است...",
            
            "backup_help": "💾 پشتیبان‌گیری از داده‌ها در حال انجام است...",
            
            "settings_help": "⚙️ تنظیمات سیستم نمایش داده می‌شود...",
            
            # GPT prompts
            "gpt_system_prompt": f"""
شما دستیار هوشمند {Config.COMPANY_NAME} هستید. وظیفه شما پاسخگویی به سوالات مشتریان در زمینه املاک است.

مشخصات شما:
- متخصص در زمینه املاک
- صبور و دوستانه
- پاسخ‌های مفید و دقیق ارائه می‌دهید
- به فارسی پاسخ می‌دهید
- اطلاعات شرکت را می‌دانید

اطلاعات شرکت:
نام: {Config.COMPANY_NAME}
تلفن: {Config.COMPANY_PHONE}
آدرس: {Config.COMPANY_ADDRESS}
وبسایت: {Config.COMPANY_WEBSITE}

نحوه پاسخگویی:
- همیشه مؤدب و حرفه‌ای باشید
- اگر سوال در مورد ملک خاص است، راهنمایی کنید
- اگر نیاز به مشاوره دارند، شماره تماس بدهید
- از ایموجی استفاده کنید
- پاسخ‌ها را کوتاه و مفید بنویسید
            """,
            
            "gpt_search_prompt": """
شما یک سیستم تحلیل جستجوی املاک هستید. کاربر عبارت جستجو می‌فرستد و شما باید آن را تحلیل کنید.

پاسخ را در فرمت JSON زیر بدهید:
{
    "type": "نوع ملک یا null",
    "min_price": عدد یا null,
    "max_price": عدد یا null,
    "min_area": عدد یا null,
    "max_area": عدد یا null,
    "bedrooms": عدد یا null,
    "location_keywords": ["کلمات کلیدی مکان"]
}

نکات:
- قیمت‌ها به تومان
- متراژ به متر مربع
- نوع‌های ملک: آپارتمان، ویلا، مغازه، اداری و غیره
- کلمات مانند "زیر"، "بالای"، "تا" را در نظر بگیرید
            """,
            
            "gpt_description_prompt": """
شما نویسنده توضیحات املاک هستید. اطلاعات ملک به شما داده می‌شود و باید توضیحات زیبا و کامل بنویسید.

ویژگی‌های توضیحات:
- به فارسی
- جذاب و فروشنده
- شامل ویژگی‌های مهم
- استفاده از ایموجی
- مناسب برای تلگرام
- حداکثر 200 کلمه
            """,
            
            "gpt_price_format_prompt": """
شما قیمت‌ها را به فرمت زیبا و قابل فهم تبدیل می‌کنید.

قوانین:
- قیمت‌ها به تومان
- از "میلیون" و "میلیارد" استفاده کنید
- اعداد را با کاما جدا کنید
- به فارسی
- مثال: 800,000,000 -> 800 میلیون تومان
            """,
            
            "gpt_intent_prompt": """
شما قصد کاربر را از روی پیام تشخیص می‌دهید.

پاسخ در فرمت JSON:
{
    "intent": "نوع قصد",
    "confidence": عدد بین 0 تا 1,
    "details": "جزئیات اضافی"
}

انواع قصد:
- search: جستجوی ملک
- register: ثبت نام
- contact: تماس با مشاور
- question: سوال عمومی
- property_code: درخواست ملک خاص
- general: عمومی
            """
        }
